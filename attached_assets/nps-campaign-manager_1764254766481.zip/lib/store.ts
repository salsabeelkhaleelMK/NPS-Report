import type {
  Campaign,
  CampaignInsights,
  SurveyQuestion,
  ReviewChannel,
  DetractorTicket,
  ReviewPerformance,
  OutcomeRules,
} from "./types"

function generateId(): string {
  return Math.random().toString(36).substring(2, 15)
}

function generateReviewPerformance(): ReviewPerformance {
  const totalRequests = Math.floor(Math.random() * 300) + 100
  const clickRate = 0.3 + Math.random() * 0.3 // 30-60% click rate
  const totalClicks = Math.floor(totalRequests * clickRate)

  const emailClicks = Math.floor(totalClicks * (0.3 + Math.random() * 0.2))
  const smsClicks = Math.floor(totalClicks * (0.2 + Math.random() * 0.15))
  const whatsappClicks = totalClicks - emailClicks - smsClicks

  return {
    totalReviewRequestsSent: totalRequests,
    totalClicks: totalClicks,
    clicksByChannel: {
      email: emailClicks,
      sms: smsClicks,
      whatsapp: whatsappClicks,
    },
    clicksByPlatform: [
      { platform: "Google", clicks: Math.floor(totalClicks * 0.45) },
      { platform: "AutoScout24", clicks: Math.floor(totalClicks * 0.3) },
      { platform: "Facebook", clicks: Math.floor(totalClicks * 0.15) },
      { platform: "mobile.de", clicks: Math.floor(totalClicks * 0.1) },
    ],
    engagementOverTime: Array.from({ length: 14 }, (_, i) => ({
      date: new Date(Date.now() - (13 - i) * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      clicks: Math.floor(Math.random() * 25) + 5,
      impressions: Math.floor(Math.random() * 60) + 20,
    })),
  }
}

function generateDefaultInsights(): CampaignInsights {
  return {
    npsScore: Math.floor(Math.random() * 40) + 30,
    promotersPercent: Math.floor(Math.random() * 30) + 40,
    passivesPercent: Math.floor(Math.random() * 20) + 20,
    detractorsPercent: Math.floor(Math.random() * 20) + 10,
    responseRate: Math.floor(Math.random() * 30) + 50,
    openDetractorTickets: Math.floor(Math.random() * 10) + 1,
    avgDetractorResolutionTime: `${Math.floor(Math.random() * 48) + 12}h`,
    responseSources: {
      email: Math.floor(Math.random() * 40) + 20,
      sms: Math.floor(Math.random() * 30) + 10,
      whatsapp: Math.floor(Math.random() * 20) + 10,
      aiCall: Math.floor(Math.random() * 20) + 5,
    },
    npsOverTime: Array.from({ length: 6 }, (_, i) => ({
      date: new Date(Date.now() - (5 - i) * 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      score: Math.floor(Math.random() * 30) + 40,
    })),
    responseRateOverTime: Array.from({ length: 6 }, (_, i) => ({
      date: new Date(Date.now() - (5 - i) * 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      rate: Math.floor(Math.random() * 20) + 50,
    })),
    aiAgentMetrics: {
      avgCallDuration: `${Math.floor(Math.random() * 3) + 1}m ${Math.floor(Math.random() * 50) + 10}s`,
      totalCalls: Math.floor(Math.random() * 500) + 100,
      responses: Math.floor(Math.random() * 300) + 50,
      unreachable: Math.floor(Math.random() * 100) + 20,
      escalatedToHuman: Math.floor(Math.random() * 30) + 5,
      escalationReasons: [
        { reason: "AI Agent Failure", count: Math.floor(Math.random() * 10) + 2 },
        { reason: "Dissatisfaction Detected", count: Math.floor(Math.random() * 15) + 3 },
        { reason: "Verbal Complaint", count: Math.floor(Math.random() * 5) + 1 },
      ],
      callsByAttempt: [
        { attempt: 1, count: Math.floor(Math.random() * 200) + 100 },
        { attempt: 2, count: Math.floor(Math.random() * 100) + 50 },
        { attempt: 3, count: Math.floor(Math.random() * 50) + 20 },
      ],
      answeredVsDropoff: Array.from({ length: 7 }, (_, i) => ({
        date: new Date(Date.now() - (6 - i) * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        answered: Math.floor(Math.random() * 50) + 30,
        dropoff: Math.floor(Math.random() * 20) + 5,
      })),
    },
    detractorTickets: [],
    reviewPerformance: generateReviewPerformance(),
  }
}

function generateDetractorTickets(count: number): DetractorTicket[] {
  const sources: ("Fidspark" | "Leadspark" | "Webhook")[] = ["Fidspark", "Leadspark", "Webhook"]
  const statuses: ("Open" | "In Progress" | "Resolved")[] = ["Open", "In Progress", "Resolved"]
  const triggerReasons: ("AI Agent Failure" | "Dissatisfaction Detected" | "Verbal Complaint" | "Low NPS Score")[] = [
    "AI Agent Failure",
    "Dissatisfaction Detected",
    "Verbal Complaint",
    "Low NPS Score",
  ]
  const names = ["John Smith", "Maria Garcia", "Hans Mueller", "Sophie Martin", "Ahmed Hassan"]

  return Array.from({ length: count }, (_, i) => ({
    id: generateId(),
    customerId: `CUST-${1000 + i}`,
    customerName: names[Math.floor(Math.random() * names.length)],
    score: Math.floor(Math.random() * 7),
    source: sources[Math.floor(Math.random() * sources.length)],
    status: statuses[Math.floor(Math.random() * statuses.length)],
    createdAt: new Date(Date.now() - Math.floor(Math.random() * 7) * 24 * 60 * 60 * 1000).toISOString(),
    triggerReason: triggerReasons[Math.floor(Math.random() * triggerReasons.length)],
  }))
}

const DEFAULT_QUESTIONS_BY_SERVICE: Record<string, SurveyQuestion[]> = {
  "New Vehicle Purchase": [
    { id: generateId(), question: "Would you like to give us your feedback?", type: "Yes/No", order: 1 },
    { id: generateId(), question: "Are you satisfied with the overall purchase process?", type: "Grade", order: 2 },
    {
      id: generateId(),
      question: "Are you satisfied with the quality of the delivery process?",
      type: "Grade",
      order: 3,
    },
    { id: generateId(), question: "Would you like to give an explanation to your score?", type: "Text", order: 4 },
  ],
  "Service Visit": [
    { id: generateId(), question: "How was your service experience?", type: "Yes/No", order: 1 },
    { id: generateId(), question: "Rate the quality of service", type: "Grade", order: 2 },
    { id: generateId(), question: "Was the service completed on time?", type: "Grade", order: 3 },
    { id: generateId(), question: "Any additional comments?", type: "Text", order: 4 },
  ],
  "Parts Purchase": [
    { id: generateId(), question: "Did you find the parts you needed?", type: "Yes/No", order: 1 },
    { id: generateId(), question: "Rate the quality of parts", type: "Grade", order: 2 },
    { id: generateId(), question: "Was delivery timely?", type: "Grade", order: 3 },
    { id: generateId(), question: "Additional feedback", type: "Text", order: 4 },
  ],
  Financing: [
    { id: generateId(), question: "Was the financing process clear?", type: "Yes/No", order: 1 },
    { id: generateId(), question: "Rate your financing experience", type: "Grade", order: 2 },
    { id: generateId(), question: "Were you satisfied with the terms?", type: "Grade", order: 3 },
    { id: generateId(), question: "Comments on financing", type: "Text", order: 4 },
  ],
  Leasing: [
    { id: generateId(), question: "Was the leasing process smooth?", type: "Yes/No", order: 1 },
    { id: generateId(), question: "Rate your leasing experience", type: "Grade", order: 2 },
    { id: generateId(), question: "Were you satisfied with leasing terms?", type: "Grade", order: 3 },
    { id: generateId(), question: "Leasing feedback", type: "Text", order: 4 },
  ],
}

function getDefaultSurveyQuestions(serviceType?: string): SurveyQuestion[] {
  const service = serviceType || "New Vehicle Purchase"
  return DEFAULT_QUESTIONS_BY_SERVICE[service] || DEFAULT_QUESTIONS_BY_SERVICE["New Vehicle Purchase"]
}

function getDefaultReviewChannels(): ReviewChannel[] {
  return [
    {
      id: generateId(),
      name: "Google",
      platformType: "Google",
      url: "https://google.com/review",
      icon: "google",
      order: 1,
      clicks: Math.floor(Math.random() * 100) + 20,
      impressions: Math.floor(Math.random() * 200) + 50,
      engagementRate: Math.floor(Math.random() * 30) + 20,
    },
    {
      id: generateId(),
      name: "AutoScout24",
      platformType: "AutoScout24",
      url: "https://autoscout24.de/review",
      icon: "car",
      order: 2,
      clicks: Math.floor(Math.random() * 80) + 10,
      impressions: Math.floor(Math.random() * 150) + 30,
      engagementRate: Math.floor(Math.random() * 25) + 15,
    },
    {
      id: generateId(),
      name: "Facebook",
      platformType: "Facebook",
      url: "https://facebook.com/review",
      icon: "facebook",
      order: 3,
      clicks: Math.floor(Math.random() * 60) + 5,
      impressions: Math.floor(Math.random() * 100) + 20,
      engagementRate: Math.floor(Math.random() * 20) + 10,
    },
  ]
}

function createSeedCampaigns(): Campaign[] {
  const now = new Date()
  const pastDate = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000)
  const futureDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000)

  const baseCampaign = {
    serviceType: "New Vehicle Purchase" as const,
    targetAudience: "All customers",
    triggerType: "Post-purchase" as const,
    triggerDescription: "Triggered after vehicle delivery",
    dataSource: "CRM" as const,
    delayBeforeContact: 3,
    followUpSteps: [
      { id: generateId(), actionType: "Send Email" as const, delayDays: 0, conditions: [] },
      {
        id: generateId(),
        actionType: "Send SMS" as const,
        delayDays: 2,
        conditions: ["Only if NOT responded" as const],
      },
      {
        id: generateId(),
        actionType: "Send AI Call" as const,
        delayDays: 5,
        conditions: ["Only if NOT responded" as const],
      },
    ],
    surveyQuestions: getDefaultSurveyQuestions(),
    reviewChannels: getDefaultReviewChannels(),
    messageTemplates: {
      email: {
        subject: "We'd love your feedback, {{name}}!",
        body: "Dear {{name}},\n\nThank you for choosing {{dealer_name}}. We'd appreciate your feedback on your recent experience.\n\nBest regards,\n{{dealer_name}}",
      },
      sms: { body: "Hi {{name}}, please share your feedback: {{review_link}}" },
      whatsapp: { templateName: "nps_survey", body: "Hi {{name}}! Rate your experience with {{dealer_name}}" },
    },
    aiAgentSettings: {
      enabled: true,
      startAfterHours: 48,
      callWindowFrom: "09:00",
      callWindowTo: "18:00",
      retryIntervalHours: 24,
      maxRetries: 3,
      targetNonRespondersOnly: true,
      voiceType: "Professional Female",
      personaScript: "Friendly and professional automotive survey agent",
      escalateToHuman: true,
      triggerHumanFollowUpOnFailure: true,
      triggerHumanFollowUpOnDissatisfaction: true,
      triggerHumanFollowUpOnVerbalComplaint: true,
    },
    outcomeRules: {
      detractors: {
        createFidsparkDispute: true,
        createLeadsparkTask: true,
        createWebhookTask: false,
        webhookUrl: "",
        webhookSecretKey: "",
        webhookJsonTemplate: "",
      },
      promoters: {
        promptReviewChannels: true,
        deliveryChannelPriority: [
          { channel: "WhatsApp" as const, enabled: true, order: 1 },
          { channel: "SMS" as const, enabled: true, order: 2 },
          { channel: "Email" as const, enabled: true, order: 3 },
        ],
      },
      passives: {
        noAction: true,
        customAction: "",
      },
    },
  }

  const insights1 = generateDefaultInsights()
  insights1.npsScore = 72
  insights1.detractorTickets = generateDetractorTickets(5)

  const insights2 = generateDefaultInsights()
  insights2.npsScore = 58
  insights2.detractorTickets = generateDetractorTickets(8)

  const insights3 = generateDefaultInsights()
  insights3.npsScore = 0
  insights3.responseRate = 0
  insights3.detractorTickets = []

  return [
    {
      ...baseCampaign,
      id: generateId(),
      name: "Q4 Customer Satisfaction - English",
      description: "Ongoing NPS campaign for English-speaking customers",
      language: "EN",
      startDate: new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      endDate: null,
      status: "Active",
      insights: insights1,
      createdAt: new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      ...baseCampaign,
      id: generateId(),
      name: "Herbst Kampagne - German",
      description: "Completed autumn campaign for German customers",
      language: "DE",
      startDate: pastDate.toISOString().split("T")[0],
      endDate: new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      status: "Completed",
      insights: insights2,
      createdAt: pastDate.toISOString(),
    },
    {
      ...baseCampaign,
      id: generateId(),
      name: "حملة رضا العملاء - Arabic",
      description: "Scheduled campaign for Arabic-speaking customers",
      language: "AR",
      startDate: futureDate.toISOString().split("T")[0],
      endDate: new Date(futureDate.getTime() + 60 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      status: "Draft",
      insights: insights3,
      createdAt: now.toISOString(),
    },
  ]
}

const STORAGE_KEY = "nps_campaigns"

function loadCampaigns(): Campaign[] {
  if (typeof window === "undefined") return createSeedCampaigns()

  const stored = localStorage.getItem(STORAGE_KEY)
  if (stored) {
    try {
      return JSON.parse(stored)
    } catch {
      return createSeedCampaigns()
    }
  }

  const seed = createSeedCampaigns()
  localStorage.setItem(STORAGE_KEY, JSON.stringify(seed))
  return seed
}

function saveCampaigns(campaigns: Campaign[]): void {
  if (typeof window === "undefined") return
  localStorage.setItem(STORAGE_KEY, JSON.stringify(campaigns))
}

export function getCampaigns(): Campaign[] {
  return loadCampaigns()
}

export function getCampaignById(id: string): Campaign | undefined {
  return loadCampaigns().find((c) => c.id === id)
}

export function createCampaign(campaignData: Partial<Campaign>): Campaign {
  const campaigns = loadCampaigns()

  const newCampaign: Campaign = {
    id: generateId(),
    name: campaignData.name || "New Campaign",
    description: campaignData.description || "",
    language: campaignData.language || "EN",
    serviceType: campaignData.serviceType || "New Vehicle Purchase",
    startDate: campaignData.startDate || new Date().toISOString().split("T")[0],
    endDate: campaignData.endDate || null,
    status: campaignData.status || "Draft",
    targetAudience: campaignData.targetAudience || "All customers",
    triggerType: campaignData.triggerType || "Post-purchase",
    triggerDescription: campaignData.triggerDescription || "",
    dataSource: campaignData.dataSource || "CRM",
    delayBeforeContact: campaignData.delayBeforeContact || 3,
    followUpSteps: campaignData.followUpSteps || [
      { id: generateId(), actionType: "Send Email", delayDays: 0, conditions: [] },
    ],
    surveyQuestions: campaignData.surveyQuestions || getDefaultSurveyQuestions(campaignData.serviceType),
    reviewChannels: campaignData.reviewChannels || getDefaultReviewChannels(),
    messageTemplates: campaignData.messageTemplates || getDefaultMessageTemplates(),
    aiAgentSettings: campaignData.aiAgentSettings || getDefaultAIAgentSettings(),
    outcomeRules: campaignData.outcomeRules || getDefaultOutcomeRules(),
    insights: generateDefaultInsights(),
    createdAt: new Date().toISOString(),
  }

  campaigns.push(newCampaign)
  saveCampaigns(campaigns)
  return newCampaign
}

export function updateCampaign(id: string, updates: Partial<Campaign>): Campaign | undefined {
  const campaigns = loadCampaigns()
  const index = campaigns.findIndex((c) => c.id === id)

  if (index === -1) return undefined

  campaigns[index] = { ...campaigns[index], ...updates }
  saveCampaigns(campaigns)
  return campaigns[index]
}

export function deleteCampaign(id: string): boolean {
  const campaigns = loadCampaigns()
  const index = campaigns.findIndex((c) => c.id === id)

  if (index === -1) return false

  campaigns.splice(index, 1)
  saveCampaigns(campaigns)
  return true
}

export function validateDetractorActions(rules: OutcomeRules): string | null {
  const hasAction =
    rules.detractors.createFidsparkDispute || rules.detractors.createLeadsparkTask || rules.detractors.createWebhookTask

  if (!hasAction) {
    return "At least one detractor action must be enabled"
  }
  return null
}

export function getDefaultMessageTemplates() {
  return {
    email: {
      subject: "We'd love your feedback, {{name}}!",
      body: "Dear {{name}},\n\nThank you for choosing {{dealer_name}}. We'd appreciate your feedback on your recent experience.\n\nBest regards,\n{{dealer_name}}",
    },
    sms: { body: "Hi {{name}}, please share your feedback: {{review_link}}" },
    whatsapp: { templateName: "nps_survey", body: "Hi {{name}}! Rate your experience with {{dealer_name}}" },
  }
}

export function getDefaultOutcomeRules() {
  return {
    detractors: {
      createFidsparkDispute: true,
      createLeadsparkTask: false,
      createWebhookTask: false,
      webhookUrl: "",
      webhookSecretKey: "",
      webhookJsonTemplate: "",
    },
    promoters: {
      promptReviewChannels: true,
      deliveryChannelPriority: [
        { channel: "WhatsApp" as const, enabled: true, order: 1 },
        { channel: "SMS" as const, enabled: true, order: 2 },
        { channel: "Email" as const, enabled: true, order: 3 },
      ],
    },
    passives: {
      noAction: true,
      customAction: "",
    },
  }
}

export function getDefaultAIAgentSettings() {
  return {
    enabled: false,
    startAfterHours: 48,
    callWindowFrom: "09:00",
    callWindowTo: "18:00",
    retryIntervalHours: 24,
    maxRetries: 3,
    targetNonRespondersOnly: true,
    voiceType: "Professional Female",
    personaScript: "Friendly and professional automotive survey agent",
    escalateToHuman: true,
    triggerHumanFollowUpOnFailure: true,
    triggerHumanFollowUpOnDissatisfaction: true,
    triggerHumanFollowUpOnVerbalComplaint: true,
  }
}

export { generateId, getDefaultSurveyQuestions, getDefaultReviewChannels, generateDefaultInsights }
