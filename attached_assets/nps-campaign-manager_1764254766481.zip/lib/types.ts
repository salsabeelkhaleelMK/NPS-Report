export type CampaignStatus = "Draft" | "Running" | "Completed" | "Scheduled" | "Active" | "Paused"
export type LanguageCode = "EN" | "DE" | "AR" | "FR" | "ES" | "IT"
export type ServiceType = "New Vehicle Purchase" | "Service Visit" | "Parts Purchase" | "Financing" | "Leasing"
export type TriggerType = "Post-purchase" | "Service visit" | "Custom"
export type DataSource = "CRM" | "CSV" | "API"
export type QuestionType = "Yes/No" | "Grade" | "Text" | "Rating"
export type DeliveryChannel = "Email" | "SMS" | "WhatsApp"

export type ActionType =
  | "Send Email"
  | "Send SMS"
  | "Send WhatsApp"
  | "Send AI Call"
  | "Create dispute on Fidspark"
  | "Create NPS Task on Leadspark"
  | "Create follow-up task via Webhook"

export type ConditionType =
  | "Only if NOT responded"
  | "Only if HAS responded"
  | "Only for NPS 0-6"
  | "Only for NPS 7-8"
  | "Only for NPS 9-10"

export interface FollowUpStep {
  id: string
  actionType: ActionType
  delayDays: number
  conditions: ConditionType[]
}

export interface SurveyQuestion {
  id: string
  question: string
  type: QuestionType
  order: number
}

export type ReviewPlatformType = "Google" | "AutoScout24" | "mobile.de" | "Facebook" | "Custom"

export interface ReviewChannel {
  id: string
  name: string
  platformType: ReviewPlatformType
  url: string
  icon: string
  order: number
  clicks: number
  impressions: number
  engagementRate: number
}

export interface DeliveryChannelPriority {
  channel: DeliveryChannel
  enabled: boolean
  order: number
}

export interface MessageTemplates {
  email: {
    subject: string
    body: string
  }
  sms: {
    body: string
  }
  whatsapp: {
    templateName: string
    body: string
  }
}

export interface AIAgentSettings {
  enabled: boolean
  startAfterHours: number
  callWindowFrom: string
  callWindowTo: string
  retryIntervalHours: number
  maxRetries: number
  targetNonRespondersOnly: boolean
  voiceType: string
  personaScript: string
  escalateToHuman: boolean
  triggerHumanFollowUpOnFailure: boolean
  triggerHumanFollowUpOnDissatisfaction: boolean
  triggerHumanFollowUpOnVerbalComplaint: boolean
}

export interface OutcomeRules {
  detractors: {
    // Human follow-up action toggles (at least one must be enabled)
    createFidsparkDispute: boolean
    createLeadsparkTask: boolean
    createWebhookTask: boolean
    webhookUrl: string
    webhookSecretKey: string
    webhookJsonTemplate: string
  }
  promoters: {
    promptReviewChannels: boolean
    deliveryChannelPriority: DeliveryChannelPriority[]
  }
  passives: {
    noAction: boolean
    customAction: string
  }
}

export interface DetractorTicket {
  id: string
  customerId: string
  customerName: string
  score: number
  source: "Fidspark" | "Leadspark" | "Webhook"
  status: "Open" | "In Progress" | "Resolved"
  createdAt: string
  triggerReason?: "AI Agent Failure" | "Dissatisfaction Detected" | "Verbal Complaint" | "Low NPS Score"
}

export interface ReviewPerformance {
  totalReviewRequestsSent: number
  totalClicks: number
  clicksByChannel: {
    email: number
    sms: number
    whatsapp: number
  }
  clicksByPlatform: { platform: string; clicks: number }[]
  engagementOverTime: { date: string; clicks: number; impressions: number }[]
}

export interface CampaignInsights {
  npsScore: number
  promotersPercent: number
  passivesPercent: number
  detractorsPercent: number
  responseRate: number
  openDetractorTickets: number
  avgDetractorResolutionTime: string
  responseSources: {
    email: number
    sms: number
    whatsapp: number
    aiCall: number
  }
  npsOverTime: { date: string; score: number }[]
  responseRateOverTime: { date: string; rate: number }[]
  aiAgentMetrics: {
    avgCallDuration: string
    totalCalls: number
    responses: number
    unreachable: number
    escalatedToHuman: number
    escalationReasons: { reason: string; count: number }[]
    callsByAttempt: { attempt: number; count: number }[]
    answeredVsDropoff: { date: string; answered: number; dropoff: number }[]
  }
  detractorTickets: DetractorTicket[]
  reviewPerformance: ReviewPerformance
}

export interface Campaign {
  id: string
  name: string
  description: string
  language: LanguageCode
  serviceType: ServiceType
  startDate: string
  endDate: string | null
  status: CampaignStatus
  targetAudience: string
  triggerType: TriggerType
  triggerDescription: string
  dataSource: DataSource
  delayBeforeContact: number
  followUpSteps: FollowUpStep[]
  surveyQuestions: SurveyQuestion[]
  reviewChannels: ReviewChannel[]
  messageTemplates: MessageTemplates
  aiAgentSettings: AIAgentSettings
  outcomeRules: OutcomeRules
  insights: CampaignInsights
  createdAt: string
}
