import { cn } from "@/lib/utils"
import type { CampaignStatus } from "@/lib/types"

interface StatusBadgeProps {
  status: CampaignStatus
  className?: string
}

const statusStyles: Record<CampaignStatus, { bg: string; text: string; label: string }> = {
  Active: { bg: "bg-status-active-bg", text: "text-status-active", label: "Active" },
  Running: { bg: "bg-status-active-bg", text: "text-status-active", label: "Active" }, // Backward compatibility
  Paused: { bg: "bg-status-paused-bg", text: "text-status-paused", label: "Paused" },
  Completed: { bg: "bg-status-info-bg", text: "text-status-info", label: "Completed" },
  Draft: { bg: "bg-status-draft-bg", text: "text-status-draft", label: "Draft" },
  Scheduled: { bg: "bg-status-draft-bg", text: "text-status-draft", label: "Draft" }, // Backward compatibility
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const styles = statusStyles[status]

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium",
        styles.bg,
        styles.text,
        className,
      )}
    >
      {styles.label}
    </span>
  )
}
