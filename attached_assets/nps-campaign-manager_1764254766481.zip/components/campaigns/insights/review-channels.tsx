"use client"

import type React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { ExternalLink, Star, Globe, Car } from "lucide-react"
import type { ReviewChannel } from "@/lib/types"

interface ReviewChannelsProps {
  channels: ReviewChannel[]
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  google: Globe,
  facebook: Globe,
  star: Star,
  car: Car,
  globe: Globe,
}

export function ReviewChannels({ channels }: ReviewChannelsProps) {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-foreground">Review Channel Performance</h2>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {channels.map((channel) => {
          const IconComponent = iconMap[channel.icon] || Globe
          return (
            <Card key={channel.id}>
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <IconComponent className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{channel.name}</p>
                      <p className="text-sm text-muted-foreground">{channel.clicks} clicks</p>
                      <p className="text-xs text-muted-foreground">{channel.engagementRate}% engagement</p>
                    </div>
                  </div>
                  <a
                    href={channel.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </div>
              </CardContent>
            </Card>
          )
        })}
        {channels.length === 0 && (
          <Card className="col-span-full">
            <CardContent className="py-12 text-center text-muted-foreground">
              No review channels configured.
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
