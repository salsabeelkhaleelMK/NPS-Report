"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { DetractorTicket } from "@/lib/types"
import { cn } from "@/lib/utils"

interface DetractorCasesProps {
  tickets: DetractorTicket[]
}

const ticketStatusStyles: Record<string, { bg: string; text: string }> = {
  Open: { bg: "bg-destructive/10", text: "text-destructive" },
  "In Progress": { bg: "bg-warning/10", text: "text-warning" },
  Resolved: { bg: "bg-success/10", text: "text-success" },
}

const triggerReasonStyles: Record<string, { bg: string; text: string }> = {
  "AI Agent Failure": { bg: "bg-orange-500/10", text: "text-orange-600" },
  "Dissatisfaction Detected": { bg: "bg-red-500/10", text: "text-red-600" },
  "Verbal Complaint": { bg: "bg-purple-500/10", text: "text-purple-600" },
  "Low NPS Score": { bg: "bg-destructive/10", text: "text-destructive" },
}

export function DetractorCases({ tickets }: DetractorCasesProps) {
  const openCount = tickets.filter((t) => t.status === "Open").length
  const inProgressCount = tickets.filter((t) => t.status === "In Progress").length
  const resolvedCount = tickets.filter((t) => t.status === "Resolved").length

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-foreground">Detractor Cases</h2>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
            {openCount} Open
          </Badge>
          <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
            {inProgressCount} In Progress
          </Badge>
          <Badge variant="outline" className="bg-success/10 text-success border-success/20">
            {resolvedCount} Resolved
          </Badge>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/50">
                  <th className="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Customer
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Score
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Ticket Source
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Trigger Reason
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Status
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Created
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {tickets.map((ticket) => {
                  const statusStyle = ticketStatusStyles[ticket.status]
                  const reasonStyle = ticket.triggerReason
                    ? triggerReasonStyles[ticket.triggerReason]
                    : { bg: "bg-muted", text: "text-muted-foreground" }
                  return (
                    <tr key={ticket.id} className="hover:bg-muted/50 transition-colors">
                      <td className="whitespace-nowrap px-6 py-4">
                        <div className="font-medium text-foreground">{ticket.customerName}</div>
                        <div className="text-xs text-muted-foreground">{ticket.customerId}</div>
                      </td>
                      <td className="whitespace-nowrap px-6 py-4">
                        <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-destructive/10 text-sm font-medium text-destructive">
                          {ticket.score}
                        </span>
                      </td>
                      <td className="whitespace-nowrap px-6 py-4 text-sm text-foreground">{ticket.source}</td>
                      <td className="whitespace-nowrap px-6 py-4">
                        {ticket.triggerReason ? (
                          <span
                            className={cn(
                              "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
                              reasonStyle.bg,
                              reasonStyle.text,
                            )}
                          >
                            {ticket.triggerReason}
                          </span>
                        ) : (
                          <span className="text-sm text-muted-foreground">-</span>
                        )}
                      </td>
                      <td className="whitespace-nowrap px-6 py-4">
                        <span
                          className={cn(
                            "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
                            statusStyle.bg,
                            statusStyle.text,
                          )}
                        >
                          {ticket.status}
                        </span>
                      </td>
                      <td className="whitespace-nowrap px-6 py-4 text-sm text-muted-foreground">
                        {new Date(ticket.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  )
                })}
                {tickets.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-muted-foreground">
                      No detractor cases found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
