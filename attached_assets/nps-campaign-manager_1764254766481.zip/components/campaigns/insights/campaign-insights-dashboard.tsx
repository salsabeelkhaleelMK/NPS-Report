"use client"

import type React from "react"

import { useState } from "react"
import { ChevronDown, ChevronUp, Users, Phone, Ticket, TrendingUp, TrendingDown, Minus } from "lucide-react"
import type { Campaign } from "@/lib/types"
import { cn } from "@/lib/utils"

interface CampaignInsightsDashboardProps {
  campaign: Campaign
}

function CollapsibleSection({
  title,
  defaultOpen = false,
  children,
}: {
  title: string
  defaultOpen?: boolean
  children: React.ReactNode
}) {
  const [isOpen, setIsOpen] = useState(defaultOpen)

  return (
    <div className="border border-border rounded-lg bg-card overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-4 text-left hover:bg-muted/50 transition-colors"
      >
        <h3 className="text-base font-semibold text-foreground">{title}</h3>
        {isOpen ? (
          <ChevronUp className="h-5 w-5 text-muted-foreground" />
        ) : (
          <ChevronDown className="h-5 w-5 text-muted-foreground" />
        )}
      </button>
      {isOpen && <div className="p-4 pt-0 border-t border-border">{children}</div>}
    </div>
  )
}

function NPSDonut({ score, size = 96 }: { score: number; size?: number }) {
  // Determine color based on score
  const getScoreColor = (score: number) => {
    if (score >= 50) return "text-success"
    if (score >= 0) return "text-warning"
    return "text-destructive"
  }

  const getTrendIcon = (score: number) => {
    if (score >= 50) return TrendingUp
    if (score >= 0) return Minus
    return TrendingDown
  }

  const TrendIcon = getTrendIcon(score)

  return (
    <div className="flex flex-col items-center gap-2">
      <div
        className="relative flex items-center justify-center rounded-full bg-muted"
        style={{ width: size, height: size }}
      >
        <div className="absolute inset-2 rounded-full bg-card flex items-center justify-center">
          <span className={cn("text-3xl font-bold", getScoreColor(score))}>{score}</span>
        </div>
      </div>
      <div className={cn("flex items-center gap-1 text-sm", getScoreColor(score))}>
        <TrendIcon className="h-4 w-4" />
        <span className="font-medium">NPS Score</span>
      </div>
    </div>
  )
}

function DistributionBar({
  promoters,
  passives,
  detractors,
}: {
  promoters: number
  passives: number
  detractors: number
}) {
  return (
    <div className="space-y-3">
      <div className="flex h-3 w-full overflow-hidden rounded-full bg-muted">
        <div className="bg-success transition-all" style={{ width: `${promoters}%` }} />
        <div className="bg-warning transition-all" style={{ width: `${passives}%` }} />
        <div className="bg-destructive transition-all" style={{ width: `${detractors}%` }} />
      </div>
      <div className="flex justify-between text-sm">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-success" />
          <span className="text-muted-foreground">Promoters</span>
          <span className="font-semibold text-foreground">{promoters}%</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-warning" />
          <span className="text-muted-foreground">Passives</span>
          <span className="font-semibold text-foreground">{passives}%</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-destructive" />
          <span className="text-muted-foreground">Detractors</span>
          <span className="font-semibold text-foreground">{detractors}%</span>
        </div>
      </div>
    </div>
  )
}

function StatCard({
  icon: Icon,
  label,
  value,
  subtext,
  variant = "default",
}: {
  icon: typeof Users
  label: string
  value: string | number
  subtext?: string
  variant?: "default" | "info" | "success" | "warning" | "destructive"
}) {
  const variantStyles = {
    default: "bg-muted/50 text-foreground",
    info: "bg-info/10 text-info",
    success: "bg-success/10 text-success",
    warning: "bg-warning/10 text-warning",
    destructive: "bg-destructive/10 text-destructive",
  }

  return (
    <div className="flex flex-col gap-3 rounded-xl border border-border bg-card p-5">
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">{label}</span>
        <div className={cn("flex h-9 w-9 items-center justify-center rounded-lg", variantStyles[variant])}>
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <div>
        <p className="text-2xl font-bold text-foreground">{value}</p>
        {subtext && <p className="text-xs text-muted-foreground mt-1">{subtext}</p>}
      </div>
    </div>
  )
}

export function CampaignInsightsDashboard({ campaign }: CampaignInsightsDashboardProps) {
  const { insights } = campaign
  const { aiAgentMetrics, reviewPerformance, detractorTickets } = insights

  const openTickets = detractorTickets.filter((t) => t.status === "Open").length
  const inProgressTickets = detractorTickets.filter((t) => t.status === "In Progress").length

  return (
    <div className="space-y-6">
      <div className="rounded-xl border border-border bg-card p-8">
        <div className="flex flex-col lg:flex-row lg:items-center gap-8">
          {/* NPS Score - Primary focus */}
          <div className="flex-shrink-0">
            <NPSDonut score={insights.npsScore} size={112} />
          </div>

          {/* Distribution Bar - Secondary focus */}
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-medium text-muted-foreground mb-4">Response Distribution</h3>
            <DistributionBar
              promoters={insights.promotersPercent}
              passives={insights.passivesPercent}
              detractors={insights.detractorsPercent}
            />
          </div>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          icon={Users}
          label="Response Rate"
          value={`${insights.responseRate}%`}
          subtext={`${insights.totalResponses} total responses`}
          variant="default"
        />
        <StatCard
          icon={Phone}
          label="AI Calls Made"
          value={aiAgentMetrics.totalCalls}
          subtext={`${aiAgentMetrics.avgCallDuration} avg duration`}
          variant="info"
        />
        <StatCard
          icon={Ticket}
          label="Open Cases"
          value={openTickets}
          subtext={`${inProgressTickets} in progress`}
          variant={openTickets > 0 ? "destructive" : "success"}
        />
        <StatCard
          icon={TrendingUp}
          label="Review Requests"
          value={reviewPerformance?.totalReviewRequestsSent ?? 0}
          subtext={`${reviewPerformance?.totalClicks ?? 0} clicks`}
          variant="success"
        />
      </div>

      {/* Collapsible sections remain unchanged */}
      <CollapsibleSection title="Review Performance" defaultOpen>
        <div className="space-y-4 pt-4">
          {reviewPerformance ? (
            <>
              <div className="grid gap-4 sm:grid-cols-3">
                <div className="rounded-lg bg-muted/50 p-4">
                  <p className="text-xs text-muted-foreground">Requests Sent</p>
                  <p className="text-xl font-semibold text-foreground mt-1">
                    {reviewPerformance.totalReviewRequestsSent ?? 0}
                  </p>
                </div>
                <div className="rounded-lg bg-muted/50 p-4">
                  <p className="text-xs text-muted-foreground">Total Clicks</p>
                  <p className="text-xl font-semibold text-foreground mt-1">{reviewPerformance.totalClicks ?? 0}</p>
                </div>
                <div className="rounded-lg bg-muted/50 p-4">
                  <p className="text-xs text-muted-foreground">Engagement Rate</p>
                  <p className="text-xl font-semibold text-foreground mt-1">
                    {reviewPerformance.totalReviewRequestsSent
                      ? ((reviewPerformance.totalClicks / reviewPerformance.totalReviewRequestsSent) * 100).toFixed(1)
                      : 0}
                    %
                  </p>
                </div>
              </div>

              {reviewPerformance.clicksByPlatform && reviewPerformance.clicksByPlatform.length > 0 && (
                <div className="space-y-3">
                  <p className="text-sm font-medium text-foreground">Clicks by Platform</p>
                  <div className="space-y-2">
                    {reviewPerformance.clicksByPlatform.map((item) => (
                      <div key={item.platform} className="flex items-center gap-3">
                        <span className="text-sm text-muted-foreground w-24">{item.platform}</span>
                        <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary rounded-full"
                            style={{
                              width: `${(item.clicks / Math.max(...reviewPerformance.clicksByPlatform.map((p) => p.clicks))) * 100}%`,
                            }}
                          />
                        </div>
                        <span className="text-sm font-medium text-foreground w-12 text-right">{item.clicks}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <p className="text-sm text-muted-foreground py-4 text-center">No review performance data available</p>
          )}
        </div>
      </CollapsibleSection>

      <CollapsibleSection title="AI Agent Activity">
        <div className="space-y-4 pt-4">
          <div className="grid gap-4 sm:grid-cols-4">
            <div className="rounded-lg bg-muted/50 p-4">
              <p className="text-xs text-muted-foreground">Avg Duration</p>
              <p className="text-xl font-semibold text-foreground mt-1">{aiAgentMetrics.avgCallDuration}</p>
            </div>
            <div className="rounded-lg bg-muted/50 p-4">
              <p className="text-xs text-muted-foreground">Responses</p>
              <p className="text-xl font-semibold text-foreground mt-1">{aiAgentMetrics.responses}</p>
            </div>
            <div className="rounded-lg bg-muted/50 p-4">
              <p className="text-xs text-muted-foreground">Unreachable</p>
              <p className="text-xl font-semibold text-foreground mt-1">{aiAgentMetrics.unreachable}</p>
            </div>
            <div className="rounded-lg bg-muted/50 p-4">
              <p className="text-xs text-muted-foreground">Escalated</p>
              <p className="text-xl font-semibold text-foreground mt-1">{aiAgentMetrics.escalatedToHuman}</p>
            </div>
          </div>

          {aiAgentMetrics.escalationReasons && aiAgentMetrics.escalationReasons.length > 0 && (
            <div className="space-y-3">
              <p className="text-sm font-medium text-foreground">Escalation Reasons</p>
              <div className="grid gap-2 sm:grid-cols-3">
                {aiAgentMetrics.escalationReasons.map((reason) => (
                  <div
                    key={reason.reason}
                    className="flex items-center justify-between rounded-lg border border-border p-3"
                  >
                    <span className="text-sm text-foreground">{reason.reason}</span>
                    <span className="text-sm font-semibold text-foreground">{reason.count}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </CollapsibleSection>

      <CollapsibleSection title={`Detractor Cases (${openTickets + inProgressTickets} active)`}>
        <div className="pt-4">
          {detractorTickets.length > 0 ? (
            <div className="space-y-2">
              {detractorTickets.slice(0, 5).map((ticket) => (
                <div key={ticket.id} className="flex items-center justify-between rounded-lg border border-border p-4">
                  <div className="flex items-center gap-4">
                    <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-destructive/10 text-sm font-semibold text-destructive">
                      {ticket.score}
                    </span>
                    <div>
                      <p className="text-sm font-medium text-foreground">{ticket.customerName}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{ticket.source}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    {ticket.triggerReason && (
                      <span className="text-xs text-muted-foreground">{ticket.triggerReason}</span>
                    )}
                    <span
                      className={cn(
                        "inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium",
                        ticket.status === "Open" && "bg-destructive/10 text-destructive",
                        ticket.status === "In Progress" && "bg-warning/10 text-warning",
                        ticket.status === "Resolved" && "bg-success/10 text-success",
                      )}
                    >
                      {ticket.status}
                    </span>
                  </div>
                </div>
              ))}
              {detractorTickets.length > 5 && (
                <p className="text-xs text-muted-foreground text-center pt-2">
                  + {detractorTickets.length - 5} more cases
                </p>
              )}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground py-4 text-center">No detractor cases found</p>
          )}
        </div>
      </CollapsibleSection>

      {/* NPS Trend - Simple text display instead of chart */}
      <CollapsibleSection title="NPS Trend">
        <div className="pt-4">
          {insights.npsOverTime && insights.npsOverTime.length > 0 ? (
            <div className="space-y-2">
              {insights.npsOverTime.map((item, index) => (
                <div key={item.date} className="flex items-center gap-4">
                  <span className="text-sm text-muted-foreground w-24">
                    {new Date(item.date).toLocaleDateString("en-US", { month: "short", year: "numeric" })}
                  </span>
                  <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full",
                        item.score >= 50 ? "bg-success" : item.score >= 0 ? "bg-warning" : "bg-destructive",
                      )}
                      style={{ width: `${Math.max(0, Math.min(100, (item.score + 100) / 2))}%` }}
                    />
                  </div>
                  <span className="text-sm font-medium text-foreground w-12 text-right">{item.score}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground py-4 text-center">No trend data available</p>
          )}
        </div>
      </CollapsibleSection>
    </div>
  )
}
