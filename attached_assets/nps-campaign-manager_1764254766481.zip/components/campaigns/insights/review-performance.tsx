"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ExternalLink, Star, Globe, Car, TrendingUp, MousePointer, Mail, MessageSquare, Phone } from "lucide-react"
import type { ReviewPerformance as ReviewPerformanceType, ReviewChannel } from "@/lib/types"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
} from "recharts"

interface ReviewPerformanceProps {
  performance: ReviewPerformanceType
  channels: ReviewChannel[]
}

const platformIconMap: Record<string, typeof Globe> = {
  google: Globe,
  car: Car,
  facebook: Globe,
  star: Star,
  globe: Globe,
}

export function ReviewPerformance({ performance, channels }: ReviewPerformanceProps) {
  if (!performance) {
    return (
      <div className="flex h-64 items-center justify-center">
        <p className="text-muted-foreground">No review performance data available</p>
      </div>
    )
  }

  const totalReviewRequestsSent = performance.totalReviewRequestsSent ?? 0
  const totalClicks = performance.totalClicks ?? 0
  const clicksByChannel = performance.clicksByChannel ?? { email: 0, sms: 0, whatsapp: 0 }
  const clicksByPlatform = performance.clicksByPlatform ?? []
  const engagementOverTime = performance.engagementOverTime ?? []

  const totalEngagementRate =
    totalReviewRequestsSent > 0 ? ((totalClicks / totalReviewRequestsSent) * 100).toFixed(1) : "0"

  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-foreground">Review Performance</h2>

      {/* Summary Metrics */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <TrendingUp className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Review Requests Sent</p>
                <p className="text-2xl font-bold text-foreground">{totalReviewRequestsSent}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-success/10">
                <MousePointer className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Clicks</p>
                <p className="text-2xl font-bold text-foreground">{totalClicks}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-info/10">
                <Star className="h-6 w-6 text-info" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Engagement Rate</p>
                <p className="text-2xl font-bold text-foreground">{totalEngagementRate}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-warning/10">
                <Globe className="h-6 w-6 text-warning" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Active Platforms</p>
                <p className="text-2xl font-bold text-foreground">{channels?.length ?? 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Clicks by Delivery Channel */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Clicks by Delivery Channel</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="flex items-center gap-4 rounded-lg border border-border p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-500/10">
                <Mail className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Email</p>
                <p className="text-xl font-bold text-foreground">{clicksByChannel.email}</p>
              </div>
            </div>

            <div className="flex items-center gap-4 rounded-lg border border-border p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-500/10">
                <MessageSquare className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">SMS</p>
                <p className="text-xl font-bold text-foreground">{clicksByChannel.sms}</p>
              </div>
            </div>

            <div className="flex items-center gap-4 rounded-lg border border-border p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/10">
                <Phone className="h-5 w-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">WhatsApp</p>
                <p className="text-xl font-bold text-foreground">{clicksByChannel.whatsapp}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Platform Performance */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Clicks by Platform</CardTitle>
          </CardHeader>
          <CardContent>
            {clicksByPlatform.length > 0 ? (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={clicksByPlatform} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis type="number" tick={{ fontSize: 12 }} />
                    <YAxis dataKey="platform" type="category" tick={{ fontSize: 12 }} width={100} />
                    <Tooltip />
                    <Bar dataKey="clicks" fill="#2563eb" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="flex h-64 items-center justify-center text-sm text-muted-foreground">
                No platform data available
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Engagement Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            {engagementOverTime.length > 0 ? (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={engagementOverTime}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis
                      dataKey="date"
                      tick={{ fontSize: 12 }}
                      tickFormatter={(value) => new Date(value).toLocaleDateString("en-US", { weekday: "short" })}
                    />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="clicks" stroke="#22c55e" strokeWidth={2} name="Clicks" />
                    <Line type="monotone" dataKey="impressions" stroke="#3b82f6" strokeWidth={2} name="Impressions" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="flex h-64 items-center justify-center text-sm text-muted-foreground">
                No engagement data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Platform Details Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Platform Details</CardTitle>
        </CardHeader>
        <CardContent>
          {channels && channels.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border text-left">
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Platform</th>
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Clicks</th>
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Impressions</th>
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Engagement Rate</th>
                    <th className="pb-3 text-sm font-medium text-muted-foreground"></th>
                  </tr>
                </thead>
                <tbody>
                  {channels.map((channel) => {
                    const IconComponent = platformIconMap[channel.icon] || Globe
                    return (
                      <tr key={channel.id} className="border-b border-border last:border-0">
                        <td className="py-4">
                          <div className="flex items-center gap-3">
                            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                              <IconComponent className="h-4 w-4 text-primary" />
                            </div>
                            <span className="font-medium text-foreground">{channel.name}</span>
                          </div>
                        </td>
                        <td className="py-4 text-foreground">{channel.clicks}</td>
                        <td className="py-4 text-foreground">{channel.impressions}</td>
                        <td className="py-4 text-foreground">{channel.engagementRate}%</td>
                        <td className="py-4">
                          <a
                            href={channel.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-muted-foreground hover:text-foreground transition-colors"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="flex h-32 items-center justify-center text-sm text-muted-foreground">
              No platform channels configured
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
