"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Trash2 } from "lucide-react"
import { generateId } from "@/lib/store"
import type { Campaign, SurveyQuestion, QuestionType } from "@/lib/types"

interface SurveyQuestionsSettingsProps {
  campaign: Campaign
  onUpdate: (updates: Partial<Campaign>) => void
}

const questionTypes: QuestionType[] = ["Yes/No", "Grade", "Text", "Rating"]

export function SurveyQuestionsSettings({ campaign, onUpdate }: SurveyQuestionsSettingsProps) {
  const addQuestion = () => {
    const newQuestion: SurveyQuestion = {
      id: generateId(),
      question: "",
      type: "Text",
      order: campaign.surveyQuestions.length + 1,
    }
    onUpdate({ surveyQuestions: [...campaign.surveyQuestions, newQuestion] })
  }

  const removeQuestion = (id: string) => {
    onUpdate({
      surveyQuestions: campaign.surveyQuestions.filter((q) => q.id !== id),
    })
  }

  const updateQuestion = (id: string, updates: Partial<SurveyQuestion>) => {
    onUpdate({
      surveyQuestions: campaign.surveyQuestions.map((q) => (q.id === id ? { ...q, ...updates } : q)),
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-medium text-foreground">Survey Questions</h3>
          <p className="text-sm text-muted-foreground">Customize the questions for this campaign</p>
        </div>
        <Button onClick={addQuestion} className="bg-slate-900 hover:bg-slate-800 text-white" size="sm">
          <Plus className="mr-2 h-4 w-4" />
          Add Question
        </Button>
      </div>

      <div className="space-y-4">
        {campaign.surveyQuestions.map((question, index) => (
          <div key={question.id} className="rounded-lg border border-border bg-card p-4 space-y-4">
            <div className="flex items-start gap-3">
              <div className="flex h-6 w-6 items-center justify-center rounded bg-muted text-xs font-medium text-muted-foreground">
                {index + 1}
              </div>
              <div className="flex-1 space-y-4">
                <div className="space-y-2">
                  <Label>Question Text</Label>
                  <Input
                    className="bg-white"
                    value={question.question}
                    onChange={(e) => updateQuestion(question.id, { question: e.target.value })}
                    placeholder="Enter your question..."
                  />
                </div>

                <div className="space-y-2">
                  <Label>Question Type</Label>
                  <Select
                    value={question.type}
                    onValueChange={(value) => updateQuestion(question.id, { type: value as QuestionType })}
                  >
                    <SelectTrigger className="bg-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {questionTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => removeQuestion(question.id)}
                className="text-muted-foreground hover:text-destructive"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}

        {campaign.surveyQuestions.length === 0 && (
          <div className="rounded-lg border border-dashed border-border py-12 text-center">
            <p className="text-muted-foreground">No questions added yet.</p>
            <Button onClick={addQuestion} className="bg-slate-900 hover:bg-slate-800 text-white mt-2">
              Add your first question
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
