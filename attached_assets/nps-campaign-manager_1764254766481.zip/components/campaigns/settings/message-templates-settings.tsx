"use client"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Mail, MessageSquare, Phone } from "lucide-react"
import type { Campaign, MessageTemplates } from "@/lib/types"

interface MessageTemplatesSettingsProps {
  campaign: Campaign
  onUpdate: (updates: Partial<Campaign>) => void
}

export function MessageTemplatesSettings({ campaign, onUpdate }: MessageTemplatesSettingsProps) {
  const updateEmailTemplate = (updates: Partial<MessageTemplates["email"]>) => {
    onUpdate({
      messageTemplates: {
        ...campaign.messageTemplates,
        email: { ...campaign.messageTemplates.email, ...updates },
      },
    })
  }

  const updateSmsTemplate = (updates: Partial<MessageTemplates["sms"]>) => {
    onUpdate({
      messageTemplates: {
        ...campaign.messageTemplates,
        sms: { ...campaign.messageTemplates.sms, ...updates },
      },
    })
  }

  const updateWhatsappTemplate = (updates: Partial<MessageTemplates["whatsapp"]>) => {
    onUpdate({
      messageTemplates: {
        ...campaign.messageTemplates,
        whatsapp: { ...campaign.messageTemplates.whatsapp, ...updates },
      },
    })
  }

  return (
    <div className="space-y-6">
      <div className="rounded-lg bg-muted/50 p-4">
        <p className="text-sm text-muted-foreground">
          <strong>Available placeholders:</strong> {`{{name}}, {{dealer_name}}, {{review_link}}, {{nps_score}}`}
        </p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Mail className="h-5 w-5 text-primary" />
            <CardTitle className="text-base">Email Template</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="emailSubject">Subject</Label>
            <Input
              id="emailSubject"
              className="bg-white"
              value={campaign.messageTemplates.email.subject}
              onChange={(e) => updateEmailTemplate({ subject: e.target.value })}
              placeholder="Email subject line..."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="emailBody">Body</Label>
            <Textarea
              id="emailBody"
              className="bg-white"
              value={campaign.messageTemplates.email.body}
              onChange={(e) => updateEmailTemplate({ body: e.target.value })}
              rows={6}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-success" />
            <CardTitle className="text-base">SMS Template</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="smsBody">Body</Label>
            <Textarea
              id="smsBody"
              className="bg-white"
              value={campaign.messageTemplates.sms.body}
              onChange={(e) => updateSmsTemplate({ body: e.target.value })}
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Phone className="h-5 w-5 text-success" />
            <CardTitle className="text-base">WhatsApp Template</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="waTemplateName">Template Name</Label>
            <Input
              id="waTemplateName"
              className="bg-white"
              value={campaign.messageTemplates.whatsapp.templateName}
              onChange={(e) => updateWhatsappTemplate({ templateName: e.target.value })}
              placeholder="template_name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="waBody">Body</Label>
            <Textarea
              id="waBody"
              className="bg-white"
              value={campaign.messageTemplates.whatsapp.body}
              onChange={(e) => updateWhatsappTemplate({ body: e.target.value })}
              rows={3}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
