"use client"

import { useState, useEffect } from "react"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import { BasicsSettings } from "./basics-settings"
import { SurveyQuestionsSettings } from "./survey-questions-settings"
import { FollowUpSettings } from "./followup-settings"
import { OutcomeRulesSettings } from "./outcome-rules-settings"
import { ReviewChannelsSettings } from "./review-channels-settings"
import { MessageTemplatesSettings } from "./message-templates-settings"
import { AIAgentSettings } from "./ai-agent-settings"
import { validateDetractorActions } from "@/lib/store"
import type { Campaign } from "@/lib/types"

interface CampaignSettingsDrawerProps {
  campaign: Campaign
  open: boolean
  onOpenChange: (open: boolean) => void
  onUpdate: (updates: Partial<Campaign>) => void
}

export function CampaignSettingsDrawer({ campaign, open, onOpenChange, onUpdate }: CampaignSettingsDrawerProps) {
  const [localCampaign, setLocalCampaign] = useState(campaign)
  const [validationError, setValidationError] = useState<string | null>(null)

  useEffect(() => {
    setLocalCampaign(campaign)
    const error = validateDetractorActions(campaign.outcomeRules)
    setValidationError(error)
  }, [campaign])

  const handleUpdate = (updates: Partial<Campaign>) => {
    const updatedCampaign = { ...localCampaign, ...updates }
    setLocalCampaign(updatedCampaign)

    if (updates.outcomeRules) {
      const error = validateDetractorActions(updatedCampaign.outcomeRules)
      setValidationError(error)
    }

    onUpdate(updates)
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full max-w-xl overflow-y-auto px-8 sm:max-w-xl">
        <SheetHeader className="mb-0">
          <SheetTitle className="text-lg mx-[-13px]">Campaign Settings</SheetTitle>
        </SheetHeader>

        {validationError && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{validationError}</AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="basics" className="w-full">
          <TabsList className="w-full justify-start border-b p-0 text-card mb-3.5 bg-background rounded-none">
            <TabsTrigger
              value="basics"
              className="border-b-2 border-transparent px-4 py-2 data-[state=active]:border-transparent data-[state=active]:bg-slate-900 data-[state=active]:text-white data-[state=active]:shadow-none"
            >
              Basics
            </TabsTrigger>
            <TabsTrigger
              value="outcomes"
              className="border-b-2 border-transparent px-4 py-2 data-[state=active]:border-transparent data-[state=active]:bg-slate-900 data-[state=active]:text-white data-[state=active]:shadow-none"
            >
              Outcomes
            </TabsTrigger>
            <TabsTrigger
              value="ai"
              className="border-b-2 border-transparent px-4 py-2 data-[state=active]:border-transparent data-[state=active]:bg-slate-900 data-[state=active]:text-white data-[state=active]:shadow-none"
            >
              AI Agent
            </TabsTrigger>
          </TabsList>

          <TabsContent value="basics" className="mt-0">
            <Accordion type="single" collapsible className="space-y-4">
              <AccordionItem value="basic-info" className="border rounded-lg bg-white">
                <AccordionTrigger className="px-4 hover:no-underline">
                  <div className="flex flex-col items-start text-left">
                    <span className="font-medium">Basic Information</span>
                    <span className="text-xs text-muted-foreground">Campaign name, dates, language</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                  <BasicsSettings campaign={localCampaign} onUpdate={handleUpdate} />
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="survey-questions" className="border rounded-lg bg-white">
                <AccordionTrigger className="px-4 hover:no-underline">
                  <div className="flex flex-col items-start text-left">
                    <span className="font-medium">Survey Questions</span>
                    <span className="text-xs text-muted-foreground">Customize survey questions</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                  <SurveyQuestionsSettings campaign={localCampaign} onUpdate={handleUpdate} />
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="followup" className="border rounded-lg bg-white">
                <AccordionTrigger className="px-4 hover:no-underline">
                  <div className="flex flex-col items-start text-left">
                    <span className="font-medium">Follow-up Flow</span>
                    <span className="text-xs text-muted-foreground">Configure follow-up actions sequence</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                  <FollowUpSettings campaign={localCampaign} onUpdate={handleUpdate} />
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="templates" className="border rounded-lg bg-white">
                <AccordionTrigger className="px-4 hover:no-underline">
                  <div className="flex flex-col items-start text-left">
                    <span className="font-medium">Message Templates</span>
                    <span className="text-xs text-muted-foreground">Email, SMS, and WhatsApp templates</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                  <MessageTemplatesSettings campaign={localCampaign} onUpdate={handleUpdate} />
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </TabsContent>

          <TabsContent value="outcomes" className="mt-0">
            <Accordion type="single" collapsible className="space-y-4">
              <AccordionItem value="outcome-rules" className="border rounded-lg bg-white">
                <AccordionTrigger className="px-4 hover:no-underline">
                  <div className="flex flex-col items-start text-left">
                    <span className="font-medium">Outcome Rules</span>
                    <span className="text-xs text-muted-foreground">Detractors, Promoters, and Passives</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                  <OutcomeRulesSettings campaign={localCampaign} onUpdate={handleUpdate} />
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="review-channels" className="border rounded-lg bg-white">
                <AccordionTrigger className="px-4 hover:no-underline">
                  <div className="flex flex-col items-start text-left">
                    <span className="font-medium">Review Channels</span>
                    <span className="text-xs text-muted-foreground">Review platforms and delivery priority</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                  <ReviewChannelsSettings campaign={localCampaign} onUpdate={handleUpdate} />
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </TabsContent>

          <TabsContent value="ai" className="space-y-6 mt-0">
            <AIAgentSettings campaign={localCampaign} onUpdate={handleUpdate} />
          </TabsContent>
        </Tabs>
      </SheetContent>
    </Sheet>
  )
}
