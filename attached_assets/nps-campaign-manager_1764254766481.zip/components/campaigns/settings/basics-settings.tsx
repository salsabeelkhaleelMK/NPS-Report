"use client"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Campaign, LanguageCode, ServiceType, CampaignStatus } from "@/lib/types"

interface BasicsSettingsProps {
  campaign: Campaign
  onUpdate: (updates: Partial<Campaign>) => void
}

export function BasicsSettings({ campaign, onUpdate }: BasicsSettingsProps) {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="name">Campaign Name</Label>
        <Input
          id="name"
          className="bg-white"
          value={campaign.name}
          onChange={(e) => onUpdate({ name: e.target.value })}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          className="bg-white"
          value={campaign.description}
          onChange={(e) => onUpdate({ description: e.target.value })}
          rows={3}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label>Language</Label>
          <Select value={campaign.language} onValueChange={(value) => onUpdate({ language: value as LanguageCode })}>
            <SelectTrigger className="bg-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="EN">English</SelectItem>
              <SelectItem value="DE">German</SelectItem>
              <SelectItem value="AR">Arabic</SelectItem>
              <SelectItem value="FR">French</SelectItem>
              <SelectItem value="ES">Spanish</SelectItem>
              <SelectItem value="IT">Italian</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Service Type</Label>
          <Select
            value={campaign.serviceType}
            onValueChange={(value) => onUpdate({ serviceType: value as ServiceType })}
          >
            <SelectTrigger className="bg-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="New Vehicle Purchase">New Vehicle Purchase</SelectItem>
              <SelectItem value="Service Visit">Service Visit</SelectItem>
              <SelectItem value="Parts Purchase">Parts Purchase</SelectItem>
              <SelectItem value="Financing">Financing</SelectItem>
              <SelectItem value="Leasing">Leasing</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="startDate">Start Date</Label>
          <Input
            id="startDate"
            type="date"
            className="bg-white"
            value={campaign.startDate}
            onChange={(e) => onUpdate({ startDate: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="endDate">End Date</Label>
          <Input
            id="endDate"
            type="date"
            className="bg-white"
            value={campaign.endDate || ""}
            onChange={(e) => onUpdate({ endDate: e.target.value || null })}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Status</Label>
        <Select value={campaign.status} onValueChange={(value) => onUpdate({ status: value as CampaignStatus })}>
          <SelectTrigger className="bg-white">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Draft">Draft</SelectItem>
            <SelectItem value="Scheduled">Scheduled</SelectItem>
            <SelectItem value="Running">Running</SelectItem>
            <SelectItem value="Completed">Completed</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  )
}
