"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent, CardHeader, CardDescription } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Trash2, GripVertical, Mail, MessageSquare, Phone } from "lucide-react"
import { generateId } from "@/lib/store"
import type { Campaign, ReviewChannel, ReviewPlatformType, DeliveryChannelPriority } from "@/lib/types"

interface ReviewChannelsSettingsProps {
  campaign: Campaign
  onUpdate: (updates: Partial<Campaign>) => void
}

const platformTypes: { value: ReviewPlatformType; label: string }[] = [
  { value: "Google", label: "Google" },
  { value: "AutoScout24", label: "AutoScout24" },
  { value: "mobile.de", label: "mobile.de" },
  { value: "Facebook", label: "Facebook" },
  { value: "Custom", label: "Custom" },
]

const platformIcons: Record<ReviewPlatformType, string> = {
  Google: "google",
  AutoScout24: "car",
  "mobile.de": "car",
  Facebook: "facebook",
  Custom: "globe",
}

export function ReviewChannelsSettings({ campaign, onUpdate }: ReviewChannelsSettingsProps) {
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null)
  const [draggedChannelIndex, setDraggedChannelIndex] = useState<number | null>(null)

  const addChannel = (platformType: ReviewPlatformType = "Custom") => {
    const newChannel: ReviewChannel = {
      id: generateId(),
      name: platformType === "Custom" ? "" : platformType,
      platformType,
      url: "",
      icon: platformIcons[platformType],
      order: campaign.reviewChannels.length + 1,
      clicks: 0,
      impressions: 0,
      engagementRate: 0,
    }
    onUpdate({ reviewChannels: [...campaign.reviewChannels, newChannel] })
  }

  const removeChannel = (id: string) => {
    onUpdate({
      reviewChannels: campaign.reviewChannels.filter((c) => c.id !== id),
    })
  }

  const updateChannel = (id: string, updates: Partial<ReviewChannel>) => {
    onUpdate({
      reviewChannels: campaign.reviewChannels.map((c) => (c.id === id ? { ...c, ...updates } : c)),
    })
  }

  const handleDragStart = (index: number) => {
    setDraggedIndex(index)
  }

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault()
    if (draggedIndex === null || draggedIndex === index) return

    const newChannels = [...campaign.reviewChannels]
    const [draggedItem] = newChannels.splice(draggedIndex, 1)
    newChannels.splice(index, 0, draggedItem)

    // Update order values
    newChannels.forEach((channel, i) => {
      channel.order = i + 1
    })

    onUpdate({ reviewChannels: newChannels })
    setDraggedIndex(index)
  }

  const handleDragEnd = () => {
    setDraggedIndex(null)
  }

  const updateDeliveryChannelPriority = (updates: DeliveryChannelPriority[]) => {
    onUpdate({
      outcomeRules: {
        ...campaign.outcomeRules,
        promoters: {
          ...campaign.outcomeRules.promoters,
          deliveryChannelPriority: updates,
        },
      },
    })
  }

  const toggleDeliveryChannel = (channel: "Email" | "SMS" | "WhatsApp", enabled: boolean) => {
    const updated = campaign.outcomeRules.promoters.deliveryChannelPriority.map((c) =>
      c.channel === channel ? { ...c, enabled } : c,
    )
    updateDeliveryChannelPriority(updated)
  }

  const handleDeliveryDragStart = (index: number) => {
    setDraggedChannelIndex(index)
  }

  const handleDeliveryDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault()
    if (draggedChannelIndex === null || draggedChannelIndex === index) return

    const newPriority = [...campaign.outcomeRules.promoters.deliveryChannelPriority]
    const [draggedItem] = newPriority.splice(draggedChannelIndex, 1)
    newPriority.splice(index, 0, draggedItem)

    newPriority.forEach((channel, i) => {
      channel.order = i + 1
    })

    updateDeliveryChannelPriority(newPriority)
    setDraggedChannelIndex(index)
  }

  const handleDeliveryDragEnd = () => {
    setDraggedChannelIndex(null)
  }

  const deliveryChannelIcons = {
    Email: Mail,
    SMS: MessageSquare,
    WhatsApp: Phone,
  }

  const deliveryChannels = campaign.outcomeRules?.promoters?.deliveryChannelPriority ?? []

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardDescription>Configure where promoters can leave reviews. Drag to reorder priority.</CardDescription>
            </div>
            <Select onValueChange={(value) => addChannel(value as ReviewPlatformType)}>
              <SelectTrigger className="w-40 bg-slate-900 hover:bg-slate-800 border-slate-900 text-card">
                <Plus className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Add Platform" />
              </SelectTrigger>
              <SelectContent>
                {platformTypes.map((platform) => (
                  <SelectItem key={platform.value} value={platform.value}>
                    {platform.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {campaign.reviewChannels.map((channel, index) => (
            <div
              key={channel.id}
              draggable
              onDragStart={() => handleDragStart(index)}
              onDragOver={(e) => handleDragOver(e, index)}
              onDragEnd={handleDragEnd}
              className={`rounded-lg border border-border bg-card p-4 transition-opacity ${
                draggedIndex === index ? "opacity-50" : ""
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="flex items-center gap-2">
                  <GripVertical className="h-5 w-5 cursor-grab text-muted-foreground" />
                  <div className="flex h-6 w-6 items-center justify-center rounded bg-muted text-xs font-medium text-muted-foreground">
                    {index + 1}
                  </div>
                </div>

                <div className="flex-1 grid gap-4 md:grid-cols-3">
                  <div className="space-y-2">
                    <Label>Platform</Label>
                    <Select
                      value={channel.platformType}
                      onValueChange={(value) =>
                        updateChannel(channel.id, {
                          platformType: value as ReviewPlatformType,
                          name: value === "Custom" ? channel.name : value,
                          icon: platformIcons[value as ReviewPlatformType],
                        })
                      }
                    >
                      <SelectTrigger className="bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {platformTypes.map((platform) => (
                          <SelectItem key={platform.value} value={platform.value}>
                            {platform.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {channel.platformType === "Custom" && (
                    <div className="space-y-2">
                      <Label>Custom Name</Label>
                      <Input
                        className="bg-white"
                        value={channel.name}
                        onChange={(e) => updateChannel(channel.id, { name: e.target.value })}
                        placeholder="Platform name"
                      />
                    </div>
                  )}

                  <div className={`space-y-2 ${channel.platformType === "Custom" ? "" : "md:col-span-2"}`}>
                    <Label>Review URL</Label>
                    <Input
                      className="bg-white"
                      value={channel.url}
                      onChange={(e) => updateChannel(channel.id, { url: e.target.value })}
                      placeholder="https://..."
                    />
                  </div>
                </div>

                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeChannel(channel.id)}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}

          {campaign.reviewChannels.length === 0 && (
            <div className="rounded-lg border border-dashed border-border py-12 text-center">
              <p className="text-muted-foreground">No review platforms added yet.</p>
              <Button onClick={() => addChannel("Google")} className="bg-slate-900 hover:bg-slate-800 text-white mt-2">
                Add your first platform
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardDescription>
            Configure how review requests are sent to promoters. Channels are tried in order based on availability.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {deliveryChannels.length > 0 ? (
            deliveryChannels.map((channelPriority, index) => {
              const IconComponent = deliveryChannelIcons[channelPriority.channel]
              return (
                <div
                  key={channelPriority.channel}
                  draggable
                  onDragStart={() => handleDeliveryDragStart(index)}
                  onDragOver={(e) => handleDeliveryDragOver(e, index)}
                  onDragEnd={handleDeliveryDragEnd}
                  className={`flex items-center justify-between rounded-lg border border-border bg-card p-4 transition-opacity ${
                    draggedChannelIndex === index ? "opacity-50" : ""
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <GripVertical className="h-5 w-5 cursor-grab text-muted-foreground" />
                    <div className="flex h-6 w-6 items-center justify-center rounded bg-muted text-xs font-medium text-muted-foreground">
                      {index + 1}
                    </div>
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                      <IconComponent className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{channelPriority.channel}</p>
                      <p className="text-xs text-muted-foreground">Uses template from Templates tab</p>
                    </div>
                  </div>
                  <Switch
                    checked={channelPriority.enabled}
                    onCheckedChange={(checked) => toggleDeliveryChannel(channelPriority.channel, checked)}
                  />
                </div>
              )
            })
          ) : (
            <div className="rounded-lg border border-dashed border-border py-12 text-center">
              <p className="text-muted-foreground">No delivery channels configured.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
