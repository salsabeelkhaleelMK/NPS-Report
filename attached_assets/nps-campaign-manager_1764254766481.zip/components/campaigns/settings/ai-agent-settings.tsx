"use client"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Bot, Info, AlertTriangle } from "lucide-react"
import type { Campaign, AIAgentSettings as AIAgentSettingsType } from "@/lib/types"

interface AIAgentSettingsProps {
  campaign: Campaign
  onUpdate: (updates: Partial<Campaign>) => void
}

const voiceTypes = ["Professional Female", "Professional Male", "Friendly Female", "Friendly Male", "Neutral"]

export function AIAgentSettings({ campaign, onUpdate }: AIAgentSettingsProps) {
  const updateSettings = (updates: Partial<AIAgentSettingsType>) => {
    onUpdate({
      aiAgentSettings: { ...campaign.aiAgentSettings, ...updates },
    })
  }

  const hasDetractorAction =
    campaign.outcomeRules.detractors.createFidsparkDispute ||
    campaign.outcomeRules.detractors.createLeadsparkTask ||
    campaign.outcomeRules.detractors.createWebhookTask

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between rounded-lg border border-border p-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            <Bot className="h-5 w-5 text-primary" />
          </div>
          <div>
            <p className="font-medium text-foreground">Enable AI Agent Follow-Up</p>
            <p className="text-sm text-muted-foreground">Automated voice calls for non-responders</p>
          </div>
        </div>
        <Switch
          checked={campaign.aiAgentSettings.enabled}
          onCheckedChange={(checked) => updateSettings({ enabled: checked })}
        />
      </div>

      {campaign.aiAgentSettings.enabled && (
        <>
          <div className="flex items-center gap-2 rounded-lg bg-muted/50 p-4">
            <Info className="h-4 w-4 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">
              Agent language matches the campaign language ({campaign.language})
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Timing</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="startAfter">Start After (hours)</Label>
                  <Input
                    id="startAfter"
                    type="number"
                    min={1}
                    className="bg-white"
                    value={campaign.aiAgentSettings.startAfterHours}
                    onChange={(e) => updateSettings({ startAfterHours: Number.parseInt(e.target.value) || 24 })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="retryInterval">Retry Interval (hours)</Label>
                  <Input
                    id="retryInterval"
                    type="number"
                    min={1}
                    className="bg-white"
                    value={campaign.aiAgentSettings.retryIntervalHours}
                    onChange={(e) => updateSettings({ retryIntervalHours: Number.parseInt(e.target.value) || 24 })}
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="callFrom">Call Window From</Label>
                  <Input
                    id="callFrom"
                    type="time"
                    className="bg-white"
                    value={campaign.aiAgentSettings.callWindowFrom}
                    onChange={(e) => updateSettings({ callWindowFrom: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="callTo">Call Window To</Label>
                  <Input
                    id="callTo"
                    type="time"
                    className="bg-white"
                    value={campaign.aiAgentSettings.callWindowTo}
                    onChange={(e) => updateSettings({ callWindowTo: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maxRetries">Max Retries</Label>
                  <Input
                    id="maxRetries"
                    type="number"
                    min={1}
                    max={10}
                    className="bg-white"
                    value={campaign.aiAgentSettings.maxRetries}
                    onChange={(e) => updateSettings({ maxRetries: Number.parseInt(e.target.value) || 3 })}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <Label htmlFor="nonResponders">Target Non-responders Only</Label>
                <Switch
                  id="nonResponders"
                  checked={campaign.aiAgentSettings.targetNonRespondersOnly}
                  onCheckedChange={(checked) => updateSettings({ targetNonRespondersOnly: checked })}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Voice & Persona</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="voiceType">Voice Type</Label>
                <Select
                  value={campaign.aiAgentSettings.voiceType}
                  onValueChange={(value) => updateSettings({ voiceType: value })}
                >
                  <SelectTrigger id="voiceType" className="bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {voiceTypes.map((voice) => (
                      <SelectItem key={voice} value={voice}>
                        {voice}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="persona">Persona Script</Label>
                <Textarea
                  id="persona"
                  className="bg-white"
                  value={campaign.aiAgentSettings.personaScript}
                  onChange={(e) => updateSettings({ personaScript: e.target.value })}
                  placeholder="Describe the AI agent's personality and communication style..."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          <Card className="border-warning/30">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-warning" />
                Human Follow-up Escalation
              </CardTitle>
              <CardDescription>
                Configure when the AI Agent should automatically trigger human follow-up actions for detractors.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {!hasDetractorAction && (
                <div className="flex items-center gap-2 rounded-lg bg-destructive/10 p-3 text-destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <p className="text-sm">No detractor actions configured. Enable actions in the Outcomes tab first.</p>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="escalateHuman">Enable Human Escalation</Label>
                  <p className="text-xs text-muted-foreground">Master toggle for escalation triggers</p>
                </div>
                <Switch
                  id="escalateHuman"
                  checked={campaign.aiAgentSettings.escalateToHuman}
                  onCheckedChange={(checked) => updateSettings({ escalateToHuman: checked })}
                />
              </div>

              {campaign.aiAgentSettings.escalateToHuman && (
                <div className="space-y-3 pt-4 border-t border-border">
                  <p className="text-sm font-medium text-foreground">Trigger human follow-up when:</p>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="failureTrigger">AI Agent fails all retries</Label>
                      <p className="text-xs text-muted-foreground">After exhausting max retries without response</p>
                    </div>
                    <Switch
                      id="failureTrigger"
                      checked={campaign.aiAgentSettings.triggerHumanFollowUpOnFailure}
                      onCheckedChange={(checked) => updateSettings({ triggerHumanFollowUpOnFailure: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="dissatisfactionTrigger">Dissatisfaction detected</Label>
                      <p className="text-xs text-muted-foreground">AI detects negative sentiment during call</p>
                    </div>
                    <Switch
                      id="dissatisfactionTrigger"
                      checked={campaign.aiAgentSettings.triggerHumanFollowUpOnDissatisfaction}
                      onCheckedChange={(checked) => updateSettings({ triggerHumanFollowUpOnDissatisfaction: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="complaintTrigger">Customer verbally complains</Label>
                      <p className="text-xs text-muted-foreground">Customer explicitly expresses a complaint</p>
                    </div>
                    <Switch
                      id="complaintTrigger"
                      checked={campaign.aiAgentSettings.triggerHumanFollowUpOnVerbalComplaint}
                      onCheckedChange={(checked) => updateSettings({ triggerHumanFollowUpOnVerbalComplaint: checked })}
                    />
                  </div>

                  {hasDetractorAction && (
                    <div className="rounded-lg bg-muted/50 p-3 mt-2">
                      <p className="text-sm text-muted-foreground">
                        <span className="font-medium text-foreground">Actions triggered:</span>{" "}
                        {[
                          campaign.outcomeRules.detractors.createFidsparkDispute && "Fidspark Dispute",
                          campaign.outcomeRules.detractors.createLeadsparkTask && "Leadspark Task",
                          campaign.outcomeRules.detractors.createWebhookTask && "Webhook",
                        ]
                          .filter(Boolean)
                          .join(", ")}
                      </p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}
