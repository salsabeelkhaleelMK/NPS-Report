"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Trash2, GripVertical } from "lucide-react"
import { generateId } from "@/lib/store"
import type { Campaign, FollowUpStep, ActionType, ConditionType } from "@/lib/types"
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core"
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"

interface FollowUpSettingsProps {
  campaign: Campaign
  onUpdate: (updates: Partial<Campaign>) => void
}

const actionTypes: ActionType[] = [
  "Send Email",
  "Send SMS",
  "Send WhatsApp",
  "Send AI Call",
  "Create dispute on Fidspark",
  "Create NPS Task on Leadspark",
  "Create follow-up task via Webhook",
]

const conditionTypes: ConditionType[] = [
  "Only if NOT responded",
  "Only if HAS responded",
  "Only for NPS 0-6",
  "Only for NPS 7-8",
  "Only for NPS 9-10",
]

function SortableStepCard({
  step,
  index,
  onUpdate,
  onRemove,
  canRemove,
  onToggleCondition,
}: {
  step: FollowUpStep
  index: number
  onUpdate: (updates: Partial<FollowUpStep>) => void
  onRemove: () => void
  canRemove: boolean
  onToggleCondition: (condition: ConditionType) => void
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: step.id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  }

  return (
    <div ref={setNodeRef} style={style} className="rounded-lg border border-border bg-card p-4 space-y-4">
      <div className="flex items-start gap-3">
        <button
          className="mt-1 cursor-grab active:cursor-grabbing text-muted-foreground hover:text-foreground"
          {...attributes}
          {...listeners}
        >
          <GripVertical className="h-5 w-5" />
        </button>

        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-sm font-medium text-primary">
          {index + 1}
        </div>
        <div className="flex-1 space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Action Type</Label>
              <Select value={step.actionType} onValueChange={(value) => onUpdate({ actionType: value as ActionType })}>
                <SelectTrigger className="bg-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {actionTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Delay (days)</Label>
              <Input
                type="number"
                min={0}
                className="bg-white"
                value={step.delayDays}
                onChange={(e) => onUpdate({ delayDays: Number.parseInt(e.target.value) || 0 })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Conditions</Label>
            <div className="flex flex-wrap gap-3">
              {conditionTypes.map((condition) => (
                <div key={condition} className="flex items-center space-x-2">
                  <Checkbox
                    id={`${step.id}-${condition}`}
                    checked={step.conditions.includes(condition)}
                    onCheckedChange={() => onToggleCondition(condition)}
                  />
                  <label htmlFor={`${step.id}-${condition}`} className="text-xs text-muted-foreground cursor-pointer">
                    {condition}
                  </label>
                </div>
              ))}
            </div>
          </div>
        </div>

        <Button
          variant="ghost"
          size="icon"
          onClick={onRemove}
          disabled={!canRemove}
          className="text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

export function FollowUpSettings({ campaign, onUpdate }: FollowUpSettingsProps) {
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  )

  const addStep = () => {
    const newStep: FollowUpStep = {
      id: generateId(),
      actionType: "Send Email",
      delayDays: 0,
      conditions: [],
    }
    onUpdate({ followUpSteps: [...campaign.followUpSteps, newStep] })
  }

  const removeStep = (id: string) => {
    onUpdate({
      followUpSteps: campaign.followUpSteps.filter((s) => s.id !== id),
    })
  }

  const updateStep = (id: string, updates: Partial<FollowUpStep>) => {
    onUpdate({
      followUpSteps: campaign.followUpSteps.map((s) => (s.id === id ? { ...s, ...updates } : s)),
    })
  }

  const toggleCondition = (stepId: string, condition: ConditionType) => {
    const step = campaign.followUpSteps.find((s) => s.id === stepId)
    if (!step) return

    const hasCondition = step.conditions.includes(condition)
    const newConditions = hasCondition
      ? step.conditions.filter((c) => c !== condition)
      : [...step.conditions, condition]

    updateStep(stepId, { conditions: newConditions })
  }

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event

    if (over && active.id !== over.id) {
      const oldIndex = campaign.followUpSteps.findIndex((s) => s.id === active.id)
      const newIndex = campaign.followUpSteps.findIndex((s) => s.id === over.id)

      const reordered = arrayMove(campaign.followUpSteps, oldIndex, newIndex)
      onUpdate({ followUpSteps: reordered })
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-medium text-foreground">Follow-up Flow</h3>
          <p className="text-sm text-muted-foreground">Configure the sequence of follow-up actions</p>
        </div>
        <Button onClick={addStep} className="bg-slate-900 hover:bg-slate-800 text-white" size="sm">
          <Plus className="mr-2 h-4 w-4" />
          Add Step
        </Button>
      </div>

      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
        <SortableContext items={campaign.followUpSteps.map((s) => s.id)} strategy={verticalListSortingStrategy}>
          <div className="space-y-4">
            {campaign.followUpSteps.map((step, index) => (
              <SortableStepCard
                key={step.id}
                step={step}
                index={index}
                onUpdate={(updates) => updateStep(step.id, updates)}
                onRemove={() => removeStep(step.id)}
                canRemove={campaign.followUpSteps.length > 1}
                onToggleCondition={(condition) => toggleCondition(step.id, condition)}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>
    </div>
  )
}
