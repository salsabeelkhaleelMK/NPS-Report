"use client"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { AlertTriangle, Info } from "lucide-react"
import type { Campaign, OutcomeRules } from "@/lib/types"

interface OutcomeRulesSettingsProps {
  campaign: Campaign
  onUpdate: (updates: Partial<Campaign>) => void
}

export function OutcomeRulesSettings({ campaign, onUpdate }: OutcomeRulesSettingsProps) {
  const updateDetractorRules = (updates: Partial<OutcomeRules["detractors"]>) => {
    onUpdate({
      outcomeRules: {
        ...campaign.outcomeRules,
        detractors: { ...campaign.outcomeRules.detractors, ...updates },
      },
    })
  }

  const updatePromoterRules = (updates: Partial<OutcomeRules["promoters"]>) => {
    onUpdate({
      outcomeRules: {
        ...campaign.outcomeRules,
        promoters: { ...campaign.outcomeRules.promoters, ...updates },
      },
    })
  }

  const updatePassiveRules = (updates: Partial<OutcomeRules["passives"]>) => {
    onUpdate({
      outcomeRules: {
        ...campaign.outcomeRules,
        passives: { ...campaign.outcomeRules.passives, ...updates },
      },
    })
  }

  const hasDetractorAction =
    campaign.outcomeRules.detractors.createFidsparkDispute ||
    campaign.outcomeRules.detractors.createLeadsparkTask ||
    campaign.outcomeRules.detractors.createWebhookTask

  return (
    <div className="space-y-6">
      <Card className="border-destructive/30">
        <CardHeader>
          <CardTitle className="text-base text-destructive flex items-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-destructive/10 text-xs font-bold">
              0-6
            </span>
            Detractors
          </CardTitle>
          <CardDescription>
            Detractors must always trigger at least one human follow-up option. These actions define how unhappy
            customers receive human attention.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!hasDetractorAction && (
            <div className="flex items-center gap-2 rounded-lg bg-destructive/10 border border-destructive/30 p-3 text-destructive">
              <AlertTriangle className="h-4 w-4 flex-shrink-0" />
              <p className="text-sm font-medium">
                Required: At least one human follow-up action must be enabled for detractors
              </p>
            </div>
          )}

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="fidspark">Create dispute in Fidspark</Label>
              <p className="text-xs text-muted-foreground">Opens a dispute case for resolution tracking</p>
            </div>
            <Switch
              id="fidspark"
              checked={campaign.outcomeRules.detractors.createFidsparkDispute}
              onCheckedChange={(checked) => updateDetractorRules({ createFidsparkDispute: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="leadspark">Create NPS Task in Leadspark</Label>
              <p className="text-xs text-muted-foreground">Creates a follow-up task for the sales team</p>
            </div>
            <Switch
              id="leadspark"
              checked={campaign.outcomeRules.detractors.createLeadsparkTask}
              onCheckedChange={(checked) => updateDetractorRules({ createLeadsparkTask: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="webhook">Create follow-up task via Webhook</Label>
              <p className="text-xs text-muted-foreground">Sends data to an external system</p>
            </div>
            <Switch
              id="webhook"
              checked={campaign.outcomeRules.detractors.createWebhookTask}
              onCheckedChange={(checked) => updateDetractorRules({ createWebhookTask: checked })}
            />
          </div>

          {campaign.outcomeRules.detractors.createWebhookTask && (
            <div className="space-y-4 pt-4 border-t border-border">
              <div className="space-y-2">
                <Label htmlFor="webhookUrl">Webhook URL</Label>
                <Input
                  id="webhookUrl"
                  className="bg-white"
                  value={campaign.outcomeRules.detractors.webhookUrl}
                  onChange={(e) => updateDetractorRules({ webhookUrl: e.target.value })}
                  placeholder="https://your-api.example.com/webhook"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="webhookSecret">Secret Key</Label>
                <Input
                  id="webhookSecret"
                  type="password"
                  className="bg-white"
                  value={campaign.outcomeRules.detractors.webhookSecretKey}
                  onChange={(e) => updateDetractorRules({ webhookSecretKey: e.target.value })}
                  placeholder="Enter secret key for authentication"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="webhookTemplate">Custom JSON Body Template</Label>
                <Textarea
                  id="webhookTemplate"
                  className="bg-white font-mono text-sm"
                  value={campaign.outcomeRules.detractors.webhookJsonTemplate}
                  onChange={(e) => updateDetractorRules({ webhookJsonTemplate: e.target.value })}
                  placeholder='{"customer_id": "{{customer_id}}", "score": {{nps_score}}, "name": "{{customer_name}}"}'
                  rows={4}
                />
                <p className="text-xs text-muted-foreground">
                  Available variables: {"{{customer_id}}"}, {"{{customer_name}}"}, {"{{nps_score}}"}, {"{{feedback}}"}
                </p>
              </div>
            </div>
          )}

          {campaign.aiAgentSettings.enabled && (
            <div className="flex items-start gap-2 rounded-lg bg-muted/50 p-3 mt-4">
              <Info className="h-4 w-4 mt-0.5 text-muted-foreground" />
              <div className="text-sm text-muted-foreground">
                <p className="font-medium text-foreground">AI Agent Integration</p>
                <p>
                  When the AI Agent fails all retries, detects dissatisfaction, or the customer verbally complains, it
                  will automatically trigger the enabled human follow-up actions above.
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-success/30">
        <CardHeader>
          <CardTitle className="text-base text-success flex items-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-success/10 text-xs font-bold">
              9-10
            </span>
            Promoters
          </CardTitle>
          <CardDescription>
            Promoters are routed to leave public reviews. They will NOT trigger escalation, tickets, or AI retries.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="reviewPrompt">Prompt review channel selection</Label>
              <p className="text-xs text-muted-foreground">
                Invites promoters to leave reviews on configured platforms
              </p>
            </div>
            <Switch
              id="reviewPrompt"
              checked={campaign.outcomeRules.promoters.promptReviewChannels}
              onCheckedChange={(checked) => updatePromoterRules({ promptReviewChannels: checked })}
            />
          </div>

          {campaign.outcomeRules.promoters.promptReviewChannels && (
            <div className="rounded-lg bg-muted/50 p-3">
              <p className="text-sm text-muted-foreground">
                Configure review platforms and delivery channel priority in the{" "}
                <span className="font-medium text-foreground">Reviews</span> tab. Set up message templates in the{" "}
                <span className="font-medium text-foreground">Templates</span> tab.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-warning/30">
        <CardHeader>
          <CardTitle className="text-base text-warning flex items-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-warning/10 text-xs font-bold">
              7-8
            </span>
            Passives
          </CardTitle>
          <CardDescription>
            Passives do NOT trigger review invites, escalation, or AI call retries by default. They are displayed in
            insights only.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="noAction">No action required</Label>
              <p className="text-xs text-muted-foreground">Display as passive in insights without additional actions</p>
            </div>
            <Switch
              id="noAction"
              checked={campaign.outcomeRules.passives.noAction}
              onCheckedChange={(checked) => updatePassiveRules({ noAction: checked })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="passiveAction">Optional Custom Action</Label>
            <Input
              id="passiveAction"
              className="bg-white"
              value={campaign.outcomeRules.passives.customAction}
              onChange={(e) => updatePassiveRules({ customAction: e.target.value })}
              placeholder="e.g., Send thank you email"
              disabled={campaign.outcomeRules.passives.noAction}
            />
            <p className="text-xs text-muted-foreground">Only active if "No action required" is disabled</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
