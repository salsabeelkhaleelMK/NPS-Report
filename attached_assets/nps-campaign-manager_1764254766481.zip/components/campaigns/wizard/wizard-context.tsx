"use client"

import { createContext, useContext, useState, type ReactNode } from "react"
import type {
  LanguageCode,
  ServiceType,
  TriggerType,
  DataSource,
  FollowUpStep,
  SurveyQuestion,
  MessageTemplates,
  OutcomeRules,
  ReviewChannel,
  AIAgentSettings,
} from "@/lib/types"
import {
  generateId,
  getDefaultSurveyQuestions,
  getDefaultMessageTemplates,
  getDefaultOutcomeRules,
  getDefaultReviewChannels,
  getDefaultAIAgentSettings,
} from "@/lib/store"

interface WizardData {
  // Step 1: Campaign Setup
  name: string
  description: string
  language: LanguageCode
  serviceType: ServiceType
  startDate: string
  endDate: string
  // Step 2: Audience & Trigger
  targetAudience: string
  triggerType: TriggerType
  triggerDescription: string
  dataSource: DataSource
  delayBeforeContact: number
  surveyQuestions: SurveyQuestion[]
  messageTemplates: MessageTemplates
  outcomeRules: OutcomeRules
  reviewChannels: ReviewChannel[]
  followUpSteps: FollowUpStep[]
  aiAgentSettings: AIAgentSettings
}

interface WizardContextType {
  step: number
  setStep: (step: number) => void
  data: WizardData
  updateData: (updates: Partial<WizardData>) => void
  isValid: (step: number) => boolean
}

const WizardContext = createContext<WizardContextType | null>(null)

export function WizardProvider({ children }: { children: ReactNode }) {
  const [step, setStep] = useState(1)
  const [data, setData] = useState<WizardData>({
    name: "",
    description: "",
    language: "EN",
    serviceType: "New Vehicle Purchase",
    startDate: new Date().toISOString().split("T")[0],
    endDate: "",
    targetAudience: "All customers",
    triggerType: "Post-purchase",
    triggerDescription: "",
    dataSource: "CRM",
    delayBeforeContact: 3,
    surveyQuestions: getDefaultSurveyQuestions("New Vehicle Purchase"),
    messageTemplates: getDefaultMessageTemplates(),
    outcomeRules: getDefaultOutcomeRules(),
    reviewChannels: getDefaultReviewChannels(),
    followUpSteps: [{ id: generateId(), actionType: "Send Email", delayDays: 0, conditions: [] }],
    aiAgentSettings: getDefaultAIAgentSettings(),
  })

  const updateData = (updates: Partial<WizardData>) => {
    setData((prev) => ({ ...prev, ...updates }))
  }

  const isValid = (stepNum: number): boolean => {
    switch (stepNum) {
      case 1:
        return data.name.trim() !== ""
      case 2:
        return true
      case 3:
        return data.surveyQuestions.length > 0
      case 4:
        return (
          data.outcomeRules.detractors.createFidsparkDispute ||
          data.outcomeRules.detractors.createLeadsparkTask ||
          data.outcomeRules.detractors.createWebhookTask
        )
      case 5:
        return data.followUpSteps.length > 0
      default:
        return false
    }
  }

  return (
    <WizardContext.Provider value={{ step, setStep, data, updateData, isValid }}>{children}</WizardContext.Provider>
  )
}

export function useWizard() {
  const context = useContext(WizardContext)
  if (!context) {
    throw new Error("useWizard must be used within a WizardProvider")
  }
  return context
}
