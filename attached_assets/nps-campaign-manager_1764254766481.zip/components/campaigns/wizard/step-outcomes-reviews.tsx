"use client"

import type React from "react"

import { useWizard } from "./wizard-context"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AlertTriangle, Plus, Trash2, GripVertical } from "lucide-react"
import { generateId } from "@/lib/store"
import type { ReviewChannel, ReviewPlatformType, OutcomeRules } from "@/lib/types"
import { useState } from "react"

const platformTypes: { value: ReviewPlatformType; label: string }[] = [
  { value: "Google", label: "Google" },
  { value: "AutoScout24", label: "AutoScout24" },
  { value: "mobile.de", label: "mobile.de" },
  { value: "Facebook", label: "Facebook" },
  { value: "Custom", label: "Custom" },
]

const platformIcons: Record<ReviewPlatformType, string> = {
  Google: "google",
  AutoScout24: "car",
  "mobile.de": "car",
  Facebook: "facebook",
  Custom: "globe",
}

export function StepOutcomesReviews() {
  const { data, updateData } = useWizard()
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null)

  const updateDetractorRules = (updates: Partial<OutcomeRules["detractors"]>) => {
    updateData({
      outcomeRules: {
        ...data.outcomeRules,
        detractors: { ...data.outcomeRules.detractors, ...updates },
      },
    })
  }

  const updatePromoterRules = (updates: Partial<OutcomeRules["promoters"]>) => {
    updateData({
      outcomeRules: {
        ...data.outcomeRules,
        promoters: { ...data.outcomeRules.promoters, ...updates },
      },
    })
  }

  const hasDetractorAction =
    data.outcomeRules.detractors.createFidsparkDispute ||
    data.outcomeRules.detractors.createLeadsparkTask ||
    data.outcomeRules.detractors.createWebhookTask

  const addChannel = (platformType: ReviewPlatformType = "Custom") => {
    const newChannel: ReviewChannel = {
      id: generateId(),
      name: platformType === "Custom" ? "" : platformType,
      platformType,
      url: "",
      icon: platformIcons[platformType],
      order: data.reviewChannels.length + 1,
      clicks: 0,
      impressions: 0,
      engagementRate: 0,
    }
    updateData({ reviewChannels: [...data.reviewChannels, newChannel] })
  }

  const removeChannel = (id: string) => {
    updateData({
      reviewChannels: data.reviewChannels.filter((c) => c.id !== id),
    })
  }

  const updateChannel = (id: string, updates: Partial<ReviewChannel>) => {
    updateData({
      reviewChannels: data.reviewChannels.map((c) => (c.id === id ? { ...c, ...updates } : c)),
    })
  }

  const handleDragStart = (index: number) => {
    setDraggedIndex(index)
  }

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault()
    if (draggedIndex === null || draggedIndex === index) return

    const newChannels = [...data.reviewChannels]
    const [draggedItem] = newChannels.splice(draggedIndex, 1)
    newChannels.splice(index, 0, draggedItem)

    newChannels.forEach((channel, i) => {
      channel.order = i + 1
    })

    updateData({ reviewChannels: newChannels })
    setDraggedIndex(index)
  }

  const handleDragEnd = () => {
    setDraggedIndex(null)
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold text-foreground">Outcomes & Reviews</h2>
        <p className="text-muted-foreground">Define actions based on NPS scores and configure review platforms</p>
      </div>

      {/* Detractors */}
      <Card className="border-destructive/30">
        <CardHeader>
          <CardTitle className="text-base text-destructive flex items-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-destructive/10 text-xs font-bold">
              0-6
            </span>
            Detractors (Angry Customers)
          </CardTitle>
          <CardDescription>At least one human follow-up action must be enabled</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!hasDetractorAction && (
            <div className="flex items-center gap-2 rounded-lg bg-destructive/10 border border-destructive/30 p-3 text-destructive">
              <AlertTriangle className="h-4 w-4 flex-shrink-0" />
              <p className="text-sm font-medium">Required: Enable at least one action below</p>
            </div>
          )}

          <div className="flex items-center justify-between">
            <div>
              <Label>Create dispute in Fidspark</Label>
              <p className="text-xs text-muted-foreground">Opens a dispute case for resolution tracking</p>
            </div>
            <Switch
              checked={data.outcomeRules.detractors.createFidsparkDispute}
              onCheckedChange={(checked) => updateDetractorRules({ createFidsparkDispute: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Create NPS Task in Leadspark</Label>
              <p className="text-xs text-muted-foreground">Creates a follow-up task for the sales team</p>
            </div>
            <Switch
              checked={data.outcomeRules.detractors.createLeadsparkTask}
              onCheckedChange={(checked) => updateDetractorRules({ createLeadsparkTask: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Create follow-up task via Webhook</Label>
              <p className="text-xs text-muted-foreground">Sends data to an external system</p>
            </div>
            <Switch
              checked={data.outcomeRules.detractors.createWebhookTask}
              onCheckedChange={(checked) => updateDetractorRules({ createWebhookTask: checked })}
            />
          </div>

          {data.outcomeRules.detractors.createWebhookTask && (
            <div className="space-y-4 pt-4 border-t border-border">
              <div className="space-y-2">
                <Label>Webhook URL</Label>
                <Input
                  value={data.outcomeRules.detractors.webhookUrl}
                  onChange={(e) => updateDetractorRules({ webhookUrl: e.target.value })}
                  placeholder="https://your-api.example.com/webhook"
                />
              </div>

              <div className="space-y-2">
                <Label>Secret Key</Label>
                <Input
                  type="password"
                  value={data.outcomeRules.detractors.webhookSecretKey}
                  onChange={(e) => updateDetractorRules({ webhookSecretKey: e.target.value })}
                  placeholder="Enter secret key"
                />
              </div>

              <div className="space-y-2">
                <Label>Custom JSON Body Template</Label>
                <Textarea
                  value={data.outcomeRules.detractors.webhookJsonTemplate}
                  onChange={(e) => updateDetractorRules({ webhookJsonTemplate: e.target.value })}
                  placeholder='{"customer_id": "{{customer_id}}"}'
                  rows={3}
                  className="font-mono text-sm"
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Promoters */}
      <Card className="border-success/30">
        <CardHeader>
          <CardTitle className="text-base text-success flex items-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-success/10 text-xs font-bold">
              9-10
            </span>
            Promoters (Satisfied Customers)
          </CardTitle>
          <CardDescription>Configure review platform invitations</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Prompt review channel selection</Label>
              <p className="text-xs text-muted-foreground">Invites promoters to leave reviews</p>
            </div>
            <Switch
              checked={data.outcomeRules.promoters.promptReviewChannels}
              onCheckedChange={(checked) => updatePromoterRules({ promptReviewChannels: checked })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Review Platforms */}
      {data.outcomeRules.promoters.promptReviewChannels && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base">Review Platforms</CardTitle>
                <CardDescription>Drag to reorder priority</CardDescription>
              </div>
              <Select onValueChange={(value) => addChannel(value as ReviewPlatformType)}>
                <SelectTrigger className="w-40">
                  <Plus className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Add Platform" />
                </SelectTrigger>
                <SelectContent>
                  {platformTypes.map((platform) => (
                    <SelectItem key={platform.value} value={platform.value}>
                      {platform.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {data.reviewChannels.map((channel, index) => (
              <div
                key={channel.id}
                draggable
                onDragStart={() => handleDragStart(index)}
                onDragOver={(e) => handleDragOver(e, index)}
                onDragEnd={handleDragEnd}
                className={`rounded-lg border border-border bg-card p-4 transition-opacity ${
                  draggedIndex === index ? "opacity-50" : ""
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="flex items-center gap-2">
                    <GripVertical className="h-5 w-5 cursor-grab text-muted-foreground" />
                    <div className="flex h-6 w-6 items-center justify-center rounded bg-muted text-xs font-medium text-muted-foreground">
                      {index + 1}
                    </div>
                  </div>

                  <div className="flex-1 grid gap-4 md:grid-cols-3">
                    <div className="space-y-2">
                      <Label>Platform</Label>
                      <Select
                        value={channel.platformType}
                        onValueChange={(value) =>
                          updateChannel(channel.id, {
                            platformType: value as ReviewPlatformType,
                            name: value === "Custom" ? channel.name : value,
                            icon: platformIcons[value as ReviewPlatformType],
                          })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {platformTypes.map((platform) => (
                            <SelectItem key={platform.value} value={platform.value}>
                              {platform.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {channel.platformType === "Custom" && (
                      <div className="space-y-2">
                        <Label>Custom Name</Label>
                        <Input
                          value={channel.name}
                          onChange={(e) => updateChannel(channel.id, { name: e.target.value })}
                          placeholder="Platform name"
                        />
                      </div>
                    )}

                    <div className={`space-y-2 ${channel.platformType === "Custom" ? "" : "md:col-span-2"}`}>
                      <Label>Review URL</Label>
                      <Input
                        value={channel.url}
                        onChange={(e) => updateChannel(channel.id, { url: e.target.value })}
                        placeholder="https://..."
                      />
                    </div>
                  </div>

                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeChannel(channel.id)}
                    className="text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}

            {data.reviewChannels.length === 0 && (
              <div className="rounded-lg border border-dashed border-border py-8 text-center">
                <p className="text-muted-foreground">No platforms added yet</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
