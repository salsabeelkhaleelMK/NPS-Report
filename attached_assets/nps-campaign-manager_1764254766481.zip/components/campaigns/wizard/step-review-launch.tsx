"use client"

import { useWizard } from "./wizard-context"
import { Check, Mail, MessageSquare, Phone, AlertCircle } from "lucide-react"

export function StepReviewLaunch() {
  const { data } = useWizard()

  const getActionIcon = (actionType: string) => {
    if (actionType.includes("Email")) return <Mail className="h-3.5 w-3.5" />
    if (actionType.includes("SMS") || actionType.includes("WhatsApp")) return <MessageSquare className="h-3.5 w-3.5" />
    if (actionType.includes("Call")) return <Phone className="h-3.5 w-3.5" />
    return <AlertCircle className="h-3.5 w-3.5" />
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-base font-semibold text-foreground mb-1">Review & Launch</h3>
        <p className="text-sm text-muted-foreground">Confirm your campaign settings before creating</p>
      </div>

      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2">
        <div className="rounded-lg border border-border p-4 space-y-3">
          <h4 className="text-sm font-medium text-foreground">Campaign Details</h4>
          <dl className="space-y-2">
            <div className="flex justify-between">
              <dt className="text-xs text-muted-foreground">Name</dt>
              <dd className="text-xs font-medium text-foreground">{data.name || "—"}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-xs text-muted-foreground">Language</dt>
              <dd className="text-xs font-medium text-foreground">{data.language}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-xs text-muted-foreground">Service Type</dt>
              <dd className="text-xs font-medium text-foreground">{data.serviceType}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-xs text-muted-foreground">Start Date</dt>
              <dd className="text-xs font-medium text-foreground">
                {data.startDate ? new Date(data.startDate).toLocaleDateString() : "—"}
              </dd>
            </div>
          </dl>
        </div>

        <div className="rounded-lg border border-border p-4 space-y-3">
          <h4 className="text-sm font-medium text-foreground">Audience & Trigger</h4>
          <dl className="space-y-2">
            <div className="flex justify-between">
              <dt className="text-xs text-muted-foreground">Target</dt>
              <dd className="text-xs font-medium text-foreground">{data.targetAudience}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-xs text-muted-foreground">Trigger</dt>
              <dd className="text-xs font-medium text-foreground">{data.triggerType}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-xs text-muted-foreground">Data Source</dt>
              <dd className="text-xs font-medium text-foreground">{data.dataSource}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-xs text-muted-foreground">Delay</dt>
              <dd className="text-xs font-medium text-foreground">{data.delayBeforeContact} days</dd>
            </div>
          </dl>
        </div>
      </div>

      {/* Follow-up Flow */}
      <div className="rounded-lg border border-border p-4 space-y-3">
        <h4 className="text-sm font-medium text-foreground">Follow-up Flow ({data.followUpSteps.length} steps)</h4>
        <div className="space-y-2">
          {data.followUpSteps.map((step, index) => (
            <div key={step.id} className="flex items-center gap-3">
              <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 text-primary">
                {getActionIcon(step.actionType)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-foreground">{step.actionType}</p>
                <p className="text-xs text-muted-foreground">
                  {step.delayDays === 0 ? "Immediately" : `After ${step.delayDays} days`}
                  {step.conditions.length > 0 && ` · ${step.conditions.length} conditions`}
                </p>
              </div>
              <Check className="h-4 w-4 text-primary shrink-0" />
            </div>
          ))}
        </div>
      </div>

      {data.description && (
        <div className="rounded-lg bg-muted/50 p-3">
          <p className="text-xs text-muted-foreground">{data.description}</p>
        </div>
      )}
    </div>
  )
}
