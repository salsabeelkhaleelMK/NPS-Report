"use client"

import { useWizard } from "./wizard-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus, Trash2, Mail, MessageSquare, Phone } from "lucide-react"
import { generateId } from "@/lib/store"
import type { SurveyQuestion, QuestionType } from "@/lib/types"

const questionTypes: QuestionType[] = ["Yes/No", "Grade", "Text", "Rating"]

export function StepSurveyTemplates() {
  const { data, updateData } = useWizard()

  const addQuestion = () => {
    const newQuestion: SurveyQuestion = {
      id: generateId(),
      question: "",
      type: "Text",
      order: data.surveyQuestions.length + 1,
    }
    updateData({ surveyQuestions: [...data.surveyQuestions, newQuestion] })
  }

  const removeQuestion = (id: string) => {
    updateData({
      surveyQuestions: data.surveyQuestions.filter((q) => q.id !== id),
    })
  }

  const updateQuestion = (id: string, updates: Partial<SurveyQuestion>) => {
    updateData({
      surveyQuestions: data.surveyQuestions.map((q) => (q.id === id ? { ...q, ...updates } : q)),
    })
  }

  const updateEmailTemplate = (updates: Partial<typeof data.messageTemplates.email>) => {
    updateData({
      messageTemplates: {
        ...data.messageTemplates,
        email: { ...data.messageTemplates.email, ...updates },
      },
    })
  }

  const updateSmsTemplate = (updates: Partial<typeof data.messageTemplates.sms>) => {
    updateData({
      messageTemplates: {
        ...data.messageTemplates,
        sms: { ...data.messageTemplates.sms, ...updates },
      },
    })
  }

  const updateWhatsappTemplate = (updates: Partial<typeof data.messageTemplates.whatsapp>) => {
    updateData({
      messageTemplates: {
        ...data.messageTemplates,
        whatsapp: { ...data.messageTemplates.whatsapp, ...updates },
      },
    })
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold text-foreground">Survey & Templates</h2>
        <p className="text-muted-foreground">Configure survey questions and message templates</p>
      </div>

      {/* Survey Questions */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-medium text-foreground">Survey Questions</h3>
            <p className="text-sm text-muted-foreground">Customize the questions for this campaign</p>
          </div>
          <Button onClick={addQuestion} variant="outline" size="sm">
            <Plus className="mr-2 h-4 w-4" />
            Add Question
          </Button>
        </div>

        <div className="space-y-3">
          {data.surveyQuestions.map((question, index) => (
            <div key={question.id} className="rounded-lg border border-border bg-card p-4 space-y-4">
              <div className="flex items-start gap-3">
                <div className="flex h-6 w-6 items-center justify-center rounded bg-muted text-xs font-medium text-muted-foreground">
                  {index + 1}
                </div>
                <div className="flex-1 space-y-4">
                  <div className="space-y-2">
                    <Label>Question Text</Label>
                    <Input
                      value={question.question}
                      onChange={(e) => updateQuestion(question.id, { question: e.target.value })}
                      placeholder="Enter your question..."
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Question Type</Label>
                    <Select
                      value={question.type}
                      onValueChange={(value) => updateQuestion(question.id, { type: value as QuestionType })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {questionTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeQuestion(question.id)}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Message Templates */}
      <div className="space-y-4">
        <div>
          <h3 className="font-medium text-foreground">Message Templates</h3>
          <p className="text-sm text-muted-foreground">
            <strong>Available placeholders:</strong> {`{{name}}, {{dealer_name}}, {{review_link}}, {{nps_score}}`}
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-primary" />
                <CardTitle className="text-base">Email Template</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Subject</Label>
                <Input
                  value={data.messageTemplates.email.subject}
                  onChange={(e) => updateEmailTemplate({ subject: e.target.value })}
                  placeholder="Email subject line..."
                />
              </div>

              <div className="space-y-2">
                <Label>Body</Label>
                <Textarea
                  value={data.messageTemplates.email.body}
                  onChange={(e) => updateEmailTemplate({ body: e.target.value })}
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-success" />
                <CardTitle className="text-base">SMS Template</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Label>Body</Label>
                <Textarea
                  value={data.messageTemplates.sms.body}
                  onChange={(e) => updateSmsTemplate({ body: e.target.value })}
                  rows={6}
                />
              </div>
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-success" />
                <CardTitle className="text-base">WhatsApp Template</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Template Name</Label>
                <Input
                  value={data.messageTemplates.whatsapp.templateName}
                  onChange={(e) => updateWhatsappTemplate({ templateName: e.target.value })}
                  placeholder="template_name"
                />
              </div>

              <div className="space-y-2">
                <Label>Body</Label>
                <Textarea
                  value={data.messageTemplates.whatsapp.body}
                  onChange={(e) => updateWhatsappTemplate({ body: e.target.value })}
                  rows={2}
                />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
