"use client"

import { useRouter } from "next/navigation"
import { WizardProvider, useWizard } from "./wizard-context"
import { StepSetup } from "./step-setup"
import { StepAudience } from "./step-audience"
import { StepSurveyTemplates } from "./step-survey-templates"
import { StepOutcomesReviews } from "./step-outcomes-reviews"
import { StepAdvanced } from "./step-advanced"
import { Button } from "@/components/ui/button"
import { createCampaign } from "@/lib/store"
import { cn } from "@/lib/utils"
import { Check } from "lucide-react"

const steps = [
  { id: 1, name: "Setup", description: "Campaign details" },
  { id: 2, name: "Audience", description: "Target & trigger" },
  { id: 3, name: "Survey", description: "Questions & templates" },
  { id: 4, name: "Outcomes", description: "Actions & reviews" },
  { id: 5, name: "Advanced", description: "Flow & AI agent" },
]

function WizardContent() {
  const router = useRouter()
  const { step, setStep, data, isValid } = useWizard()

  const handleNext = () => {
    if (step < 5) {
      setStep(step + 1)
    }
  }

  const handlePrev = () => {
    if (step > 1) {
      setStep(step - 1)
    }
  }

  const handleCreate = () => {
    const campaign = createCampaign({
      name: data.name,
      description: data.description,
      language: data.language,
      serviceType: data.serviceType,
      startDate: data.startDate,
      endDate: data.endDate || null,
      status: "Draft",
      targetAudience: data.targetAudience,
      triggerType: data.triggerType,
      triggerDescription: data.triggerDescription,
      dataSource: data.dataSource,
      delayBeforeContact: data.delayBeforeContact,
      surveyQuestions: data.surveyQuestions,
      messageTemplates: data.messageTemplates,
      outcomeRules: data.outcomeRules,
      reviewChannels: data.reviewChannels,
      followUpSteps: data.followUpSteps,
      aiAgentSettings: data.aiAgentSettings,
    })

    router.push(`/campaigns/${campaign.id}`)
  }

  return (
    <div className="space-y-8">
      <nav aria-label="Progress">
        <ol className="flex items-center justify-between">
          {steps.map((s, index) => (
            <li key={s.id} className="relative flex items-center">
              {/* Step indicator and text */}
              <div className="flex items-center gap-3">
                <div
                  className={cn(
                    "flex h-10 w-10 items-center justify-center rounded-full text-sm font-semibold transition-colors",
                    step > s.id
                      ? "bg-primary text-primary-foreground"
                      : step === s.id
                        ? "bg-primary/10 text-primary border-2 border-primary"
                        : "bg-muted text-muted-foreground",
                  )}
                >
                  {step > s.id ? <Check className="h-5 w-5" /> : <span>{s.id}</span>}
                </div>
                <div className="hidden sm:block">
                  <p className={cn("text-sm font-medium", step >= s.id ? "text-foreground" : "text-muted-foreground")}>
                    {s.name}
                  </p>
                  <p className="text-xs text-muted-foreground">{s.description}</p>
                </div>
              </div>

              {/* Connector line */}
              {index !== steps.length - 1 && (
                <div className="flex items-center px-4 sm:px-6 md:px-8">
                  <div
                    className={cn(
                      "h-0.5 w-12 sm:w-16 md:w-24 transition-colors",
                      step > s.id ? "bg-primary" : "bg-border",
                    )}
                  />
                </div>
              )}
            </li>
          ))}
        </ol>
      </nav>

      {/* Step Content */}
      <div className="rounded-lg border border-border bg-card p-6">
        {step === 1 && <StepSetup />}
        {step === 2 && <StepAudience />}
        {step === 3 && <StepSurveyTemplates />}
        {step === 4 && <StepOutcomesReviews />}
        {step === 5 && <StepAdvanced />}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between">
        <Button variant="outline" size="sm" onClick={handlePrev} disabled={step === 1}>
          Previous
        </Button>
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" onClick={() => router.push("/")}>
            Cancel
          </Button>
          {step < 5 ? (
            <Button size="sm" onClick={handleNext} disabled={!isValid(step)}>
              Continue
            </Button>
          ) : (
            <Button size="sm" onClick={handleCreate} disabled={!isValid(5)}>
              Create Campaign
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}

export function CampaignWizard() {
  return (
    <WizardProvider>
      <WizardContent />
    </WizardProvider>
  )
}
