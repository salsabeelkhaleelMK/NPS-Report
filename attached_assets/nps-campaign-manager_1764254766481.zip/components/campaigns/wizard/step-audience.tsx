"use client"

import { useWizard } from "./wizard-context"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { TriggerType, DataSource } from "@/lib/types"

export function StepAudience() {
  const { data, updateData } = useWizard()

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-base font-semibold text-foreground mb-1">Audience & Trigger</h3>
        <p className="text-sm text-muted-foreground">Define who receives this survey and when</p>
      </div>

      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2">
        <div className="space-y-2 col-span-full">
          <Label htmlFor="targetAudience" className="text-sm">
            Target Audience
          </Label>
          <Input
            id="targetAudience"
            value={data.targetAudience}
            onChange={(e) => updateData({ targetAudience: e.target.value })}
            placeholder="e.g., All customers, VIP customers, etc."
            className="h-9"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-sm">Trigger Type</Label>
          <Select value={data.triggerType} onValueChange={(value) => updateData({ triggerType: value as TriggerType })}>
            <SelectTrigger className="h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Post-purchase">Post-purchase</SelectItem>
              <SelectItem value="Service visit">Service visit</SelectItem>
              <SelectItem value="Custom">Custom</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label className="text-sm">Data Source</Label>
          <Select value={data.dataSource} onValueChange={(value) => updateData({ dataSource: value as DataSource })}>
            <SelectTrigger className="h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="CRM">CRM</SelectItem>
              <SelectItem value="CSV">CSV Import</SelectItem>
              <SelectItem value="API">API Integration</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="delayBeforeContact" className="text-sm">
            Delay Before Contact (days)
          </Label>
          <Input
            id="delayBeforeContact"
            type="number"
            min={0}
            value={data.delayBeforeContact}
            onChange={(e) => updateData({ delayBeforeContact: Number.parseInt(e.target.value) || 0 })}
            className="h-9"
          />
        </div>

        <div className="space-y-2 col-span-full">
          <Label htmlFor="triggerDescription" className="text-sm">
            Trigger Description (optional)
          </Label>
          <Textarea
            id="triggerDescription"
            value={data.triggerDescription}
            onChange={(e) => updateData({ triggerDescription: e.target.value })}
            placeholder="Additional details about the trigger..."
            rows={2}
            className="resize-none"
          />
        </div>
      </div>
    </div>
  )
}
