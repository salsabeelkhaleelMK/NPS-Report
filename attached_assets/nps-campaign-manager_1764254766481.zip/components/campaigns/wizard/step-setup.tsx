"use client"

import { useEffect, useState } from "react"
import { useWizard } from "./wizard-context"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { getDefaultSurveyQuestions } from "@/lib/store"
import type { LanguageCode, ServiceType } from "@/lib/types"

export function StepSetup() {
  const { data, updateData } = useWizard()
  const [showReplaceDialog, setShowReplaceDialog] = useState(false)
  const [pendingServiceType, setPendingServiceType] = useState<ServiceType | null>(null)
  const [questionsModified, setQuestionsModified] = useState(false)

  useEffect(() => {
    if (!data.surveyQuestions || data.surveyQuestions.length === 0) {
      const defaultQuestions = getDefaultSurveyQuestions(data.serviceType)
      updateData({ surveyQuestions: defaultQuestions })
    }
  }, [])

  const handleServiceTypeChange = (newServiceType: ServiceType) => {
    const hasExistingQuestions = data.surveyQuestions && data.surveyQuestions.length > 0

    if (hasExistingQuestions && newServiceType !== data.serviceType && questionsModified) {
      setPendingServiceType(newServiceType)
      setShowReplaceDialog(true)
    } else {
      applyServiceTypeChange(newServiceType)
    }
  }

  const applyServiceTypeChange = (newServiceType: ServiceType) => {
    const newQuestions = getDefaultSurveyQuestions(newServiceType)
    updateData({
      serviceType: newServiceType,
      surveyQuestions: newQuestions,
    })
    setQuestionsModified(false)
  }

  return (
    <>
      <div className="space-y-6">
        <div>
          <h3 className="text-base font-semibold text-foreground mb-1">Campaign Setup</h3>
          <p className="text-sm text-muted-foreground">Basic information about your NPS campaign</p>
        </div>

        <div className="grid gap-6 grid-cols-1 sm:grid-cols-2">
          <div className="space-y-2 col-span-full">
            <Label htmlFor="name" className="text-sm">
              Campaign Name *
            </Label>
            <Input
              id="name"
              value={data.name}
              onChange={(e) => updateData({ name: e.target.value })}
              placeholder="e.g., Q4 Customer Satisfaction Survey"
              className="h-9"
            />
          </div>

          <div className="space-y-2 col-span-full">
            <Label htmlFor="description" className="text-sm">
              Description
            </Label>
            <Textarea
              id="description"
              value={data.description}
              onChange={(e) => updateData({ description: e.target.value })}
              placeholder="Brief description of this campaign..."
              rows={2}
              className="resize-none"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-sm">Language</Label>
            <Select value={data.language} onValueChange={(value) => updateData({ language: value as LanguageCode })}>
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="EN">English</SelectItem>
                <SelectItem value="DE">German</SelectItem>
                <SelectItem value="AR">Arabic</SelectItem>
                <SelectItem value="FR">French</SelectItem>
                <SelectItem value="ES">Spanish</SelectItem>
                <SelectItem value="IT">Italian</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-sm">Service Type</Label>
            <Select value={data.serviceType} onValueChange={(value) => handleServiceTypeChange(value as ServiceType)}>
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="New Vehicle Purchase">New Vehicle Purchase</SelectItem>
                <SelectItem value="Service Visit">Service Visit</SelectItem>
                <SelectItem value="Parts Purchase">Parts Purchase</SelectItem>
                <SelectItem value="Financing">Financing</SelectItem>
                <SelectItem value="Leasing">Leasing</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="startDate" className="text-sm">
              Start Date
            </Label>
            <Input
              id="startDate"
              type="date"
              value={data.startDate}
              onChange={(e) => updateData({ startDate: e.target.value })}
              className="h-9"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="endDate" className="text-sm">
              End Date (optional)
            </Label>
            <Input
              id="endDate"
              type="date"
              value={data.endDate}
              onChange={(e) => updateData({ endDate: e.target.value })}
              className="h-9"
            />
          </div>
        </div>
      </div>

      <AlertDialog open={showReplaceDialog} onOpenChange={setShowReplaceDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Replace Survey Questions?</AlertDialogTitle>
            <AlertDialogDescription>
              Changing the service type from "{data.serviceType}" to "{pendingServiceType}" will replace your current
              survey questions with the default questions for this service type. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setPendingServiceType(null)}>Keep Current Questions</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (pendingServiceType) {
                  applyServiceTypeChange(pendingServiceType)
                }
                setShowReplaceDialog(false)
                setPendingServiceType(null)
              }}
            >
              Replace Questions
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
