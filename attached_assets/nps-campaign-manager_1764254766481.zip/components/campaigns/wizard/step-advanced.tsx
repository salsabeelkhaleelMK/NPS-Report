"use client"

import { useWizard } from "./wizard-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus, Trash2, GripVertical, Bot, AlertTriangle, Info } from "lucide-react"
import { generateId } from "@/lib/store"
import type { FollowUpStep, ActionType, ConditionType, AIAgentSettings } from "@/lib/types"
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core"
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"

const actionTypes: ActionType[] = [
  "Send Email",
  "Send SMS",
  "Send WhatsApp",
  "Send AI Call",
  "Create dispute on Fidspark",
  "Create NPS Task on Leadspark",
  "Create follow-up task via Webhook",
]

const conditionTypes: ConditionType[] = [
  "Only if NOT responded",
  "Only if HAS responded",
  "Only for NPS 0-6",
  "Only for NPS 7-8",
  "Only for NPS 9-10",
]

const voiceTypes = ["Professional Female", "Professional Male", "Friendly Female", "Friendly Male", "Neutral"]

function SortableStepCard({
  step,
  index,
  onUpdate,
  onRemove,
  canRemove,
  onToggleCondition,
}: {
  step: FollowUpStep
  index: number
  onUpdate: (updates: Partial<FollowUpStep>) => void
  onRemove: () => void
  canRemove: boolean
  onToggleCondition: (condition: ConditionType) => void
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: step.id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  }

  return (
    <div ref={setNodeRef} style={style} className="rounded-lg border border-border bg-card p-4 space-y-4">
      <div className="flex items-start gap-3">
        <button
          className="mt-1 cursor-grab active:cursor-grabbing text-muted-foreground hover:text-foreground"
          {...attributes}
          {...listeners}
        >
          <GripVertical className="h-5 w-5" />
        </button>

        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-sm font-medium text-primary">
          {index + 1}
        </div>
        <div className="flex-1 space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Action Type</Label>
              <Select value={step.actionType} onValueChange={(value) => onUpdate({ actionType: value as ActionType })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {actionTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Delay (days)</Label>
              <Input
                type="number"
                min={0}
                value={step.delayDays}
                onChange={(e) => onUpdate({ delayDays: Number.parseInt(e.target.value) || 0 })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Conditions</Label>
            <div className="flex flex-wrap gap-3">
              {conditionTypes.map((condition) => (
                <div key={condition} className="flex items-center space-x-2">
                  <Checkbox
                    id={`${step.id}-${condition}`}
                    checked={step.conditions.includes(condition)}
                    onCheckedChange={() => onToggleCondition(condition)}
                  />
                  <label htmlFor={`${step.id}-${condition}`} className="text-xs text-muted-foreground cursor-pointer">
                    {condition}
                  </label>
                </div>
              ))}
            </div>
          </div>
        </div>

        <Button
          variant="ghost"
          size="icon"
          onClick={onRemove}
          disabled={!canRemove}
          className="text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

export function StepAdvanced() {
  const { data, updateData } = useWizard()

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  )

  const addStep = () => {
    const newStep: FollowUpStep = {
      id: generateId(),
      actionType: "Send Email",
      delayDays: 0,
      conditions: [],
    }
    updateData({ followUpSteps: [...data.followUpSteps, newStep] })
  }

  const removeStep = (id: string) => {
    updateData({
      followUpSteps: data.followUpSteps.filter((s) => s.id !== id),
    })
  }

  const updateStep = (id: string, updates: Partial<FollowUpStep>) => {
    updateData({
      followUpSteps: data.followUpSteps.map((s) => (s.id === id ? { ...s, ...updates } : s)),
    })
  }

  const toggleCondition = (stepId: string, condition: ConditionType) => {
    const step = data.followUpSteps.find((s) => s.id === stepId)
    if (!step) return

    const hasCondition = step.conditions.includes(condition)
    const newConditions = hasCondition
      ? step.conditions.filter((c) => c !== condition)
      : [...step.conditions, condition]

    updateStep(stepId, { conditions: newConditions })
  }

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event

    if (over && active.id !== over.id) {
      const oldIndex = data.followUpSteps.findIndex((s) => s.id === active.id)
      const newIndex = data.followUpSteps.findIndex((s) => s.id === over.id)

      const reordered = arrayMove(data.followUpSteps, oldIndex, newIndex)
      updateData({ followUpSteps: reordered })
    }
  }

  const updateAISettings = (updates: Partial<AIAgentSettings>) => {
    updateData({
      aiAgentSettings: { ...data.aiAgentSettings, ...updates },
    })
  }

  const hasDetractorAction =
    data.outcomeRules.detractors.createFidsparkDispute ||
    data.outcomeRules.detractors.createLeadsparkTask ||
    data.outcomeRules.detractors.createWebhookTask

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold text-foreground">Advanced Options</h2>
        <p className="text-muted-foreground">Configure follow-up flow and AI agent (optional)</p>
      </div>

      {/* Follow-up Flow */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-medium text-foreground">Follow-up Flow</h3>
            <p className="text-sm text-muted-foreground">Define the sequence of follow-up actions</p>
          </div>
          <Button onClick={addStep} variant="outline" size="sm">
            <Plus className="mr-2 h-4 w-4" />
            Add Step
          </Button>
        </div>

        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
          <SortableContext items={data.followUpSteps.map((s) => s.id)} strategy={verticalListSortingStrategy}>
            <div className="space-y-3">
              {data.followUpSteps.map((step, index) => (
                <SortableStepCard
                  key={step.id}
                  step={step}
                  index={index}
                  onUpdate={(updates) => updateStep(step.id, updates)}
                  onRemove={() => removeStep(step.id)}
                  canRemove={data.followUpSteps.length > 1}
                  onToggleCondition={(condition) => toggleCondition(step.id, condition)}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      </div>

      {/* AI Agent */}
      <div className="space-y-4">
        <div className="flex items-center justify-between rounded-lg border border-border p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <Bot className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="font-medium text-foreground">Enable AI Agent Follow-Up</p>
              <p className="text-sm text-muted-foreground">Automated voice calls for non-responders</p>
            </div>
          </div>
          <Switch
            checked={data.aiAgentSettings.enabled}
            onCheckedChange={(checked) => updateAISettings({ enabled: checked })}
          />
        </div>

        {data.aiAgentSettings.enabled && (
          <>
            <div className="flex items-center gap-2 rounded-lg bg-muted/50 p-4">
              <Info className="h-4 w-4 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                Agent language matches the campaign language ({data.language})
              </p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Timing</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Start After (hours)</Label>
                    <Input
                      type="number"
                      min={1}
                      value={data.aiAgentSettings.startAfterHours}
                      onChange={(e) => updateAISettings({ startAfterHours: Number.parseInt(e.target.value) || 24 })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Retry Interval (hours)</Label>
                    <Input
                      type="number"
                      min={1}
                      value={data.aiAgentSettings.retryIntervalHours}
                      onChange={(e) => updateAISettings({ retryIntervalHours: Number.parseInt(e.target.value) || 24 })}
                    />
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-3">
                  <div className="space-y-2">
                    <Label>Call Window From</Label>
                    <Input
                      type="time"
                      value={data.aiAgentSettings.callWindowFrom}
                      onChange={(e) => updateAISettings({ callWindowFrom: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Call Window To</Label>
                    <Input
                      type="time"
                      value={data.aiAgentSettings.callWindowTo}
                      onChange={(e) => updateAISettings({ callWindowTo: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Max Retries</Label>
                    <Input
                      type="number"
                      min={1}
                      max={10}
                      value={data.aiAgentSettings.maxRetries}
                      onChange={(e) => updateAISettings({ maxRetries: Number.parseInt(e.target.value) || 3 })}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Voice & Persona</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Voice Type</Label>
                  <Select
                    value={data.aiAgentSettings.voiceType}
                    onValueChange={(value) => updateAISettings({ voiceType: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {voiceTypes.map((voice) => (
                        <SelectItem key={voice} value={voice}>
                          {voice}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Persona Script</Label>
                  <Textarea
                    value={data.aiAgentSettings.personaScript}
                    onChange={(e) => updateAISettings({ personaScript: e.target.value })}
                    placeholder="Describe the AI agent's personality..."
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="border-warning/30">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-warning" />
                  Human Follow-up Escalation
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {!hasDetractorAction && (
                  <div className="flex items-center gap-2 rounded-lg bg-destructive/10 p-3 text-destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <p className="text-sm">No detractor actions configured in Step 4</p>
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Enable Human Escalation</Label>
                    <p className="text-xs text-muted-foreground">Master toggle for escalation triggers</p>
                  </div>
                  <Switch
                    checked={data.aiAgentSettings.escalateToHuman}
                    onCheckedChange={(checked) => updateAISettings({ escalateToHuman: checked })}
                  />
                </div>

                {data.aiAgentSettings.escalateToHuman && (
                  <div className="space-y-3 pt-4 border-t border-border">
                    <div className="flex items-center justify-between">
                      <Label>AI Agent fails all retries</Label>
                      <Switch
                        checked={data.aiAgentSettings.triggerHumanFollowUpOnFailure}
                        onCheckedChange={(checked) => updateAISettings({ triggerHumanFollowUpOnFailure: checked })}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label>Dissatisfaction detected</Label>
                      <Switch
                        checked={data.aiAgentSettings.triggerHumanFollowUpOnDissatisfaction}
                        onCheckedChange={(checked) =>
                          updateAISettings({ triggerHumanFollowUpOnDissatisfaction: checked })
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label>Customer verbally complains</Label>
                      <Switch
                        checked={data.aiAgentSettings.triggerHumanFollowUpOnVerbalComplaint}
                        onCheckedChange={(checked) =>
                          updateAISettings({ triggerHumanFollowUpOnVerbalComplaint: checked })
                        }
                      />
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  )
}
