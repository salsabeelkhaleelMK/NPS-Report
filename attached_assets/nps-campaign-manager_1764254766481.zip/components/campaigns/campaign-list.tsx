"use client"

import { useState, useMemo } from "react"
import { useRouter } from "next/navigation"
import { Search, Plus, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { StatusBadge } from "@/components/ui/status-badge"
import type { Campaign } from "@/lib/types"

interface CampaignListProps {
  campaigns: Campaign[]
}

function CampaignCard({ campaign, onClick }: { campaign: Campaign; onClick: () => void }) {
  return (
    <div
      className="group flex items-center justify-between rounded-lg border border-border bg-card p-4 cursor-pointer transition-all hover:border-primary/30 hover:shadow-sm"
      onClick={onClick}
    >
      {/* Left: Identity + Status */}
      <div className="flex items-center gap-4 flex-1 min-w-0">
        <div className="flex-1 min-w-0">
          {/* Primary: Name + Status - largest visual weight */}
          <div className="flex items-center gap-2.5 mb-1">
            <h3 className="text-sm font-semibold text-foreground truncate">{campaign.name}</h3>
            <StatusBadge status={campaign.status} />
          </div>
          {/* Tertiary: Metadata - smallest, muted */}
          <p className="text-xs text-muted-foreground">
            {campaign.serviceType} · {campaign.language}
          </p>
        </div>
      </div>

      {/* Right: Key metric + Action hint */}
      <div className="flex items-center gap-6 shrink-0">
        {/* Secondary: Key metric - second visual weight */}
        <div className="text-right">
          <p className="text-2xl font-semibold text-foreground leading-none">{campaign.insights.npsScore}</p>
          <p className="text-xs text-muted-foreground mt-0.5">NPS</p>
        </div>

        {/* Hover-reveal arrow */}
        <ChevronRight className="h-5 w-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
    </div>
  )
}

export function CampaignList({ campaigns }: CampaignListProps) {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")

  const filteredCampaigns = useMemo(() => {
    const query = searchQuery.toLowerCase()
    return campaigns.filter((campaign) => {
      return (
        campaign.name.toLowerCase().includes(query) ||
        campaign.language.toLowerCase().includes(query) ||
        campaign.serviceType.toLowerCase().includes(query) ||
        campaign.status.toLowerCase().includes(query) ||
        campaign.description.toLowerCase().includes(query)
      )
    })
  }, [campaigns, searchQuery])

  const handleCardClick = (campaignId: string) => {
    router.push(`/campaigns/${campaignId}`)
  }

  return (
    <div className="space-y-6">
      {/* Header with search and action */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search campaigns..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 h-9 bg-card border-border text-sm"
          />
        </div>

        <Button onClick={() => router.push("/campaigns/new")} size="sm" className="gap-2">
          <Plus className="h-4 w-4" />
          New Campaign
        </Button>
      </div>

      {filteredCampaigns.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-lg border border-border bg-card p-12">
          <p className="text-sm text-muted-foreground">No campaigns found</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filteredCampaigns.map((campaign) => (
            <CampaignCard key={campaign.id} campaign={campaign} onClick={() => handleCardClick(campaign.id)} />
          ))}
        </div>
      )}
    </div>
  )
}
