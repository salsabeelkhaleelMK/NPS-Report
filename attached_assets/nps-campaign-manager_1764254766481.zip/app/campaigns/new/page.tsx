"use client"

import { useRouter } from "next/navigation"
import { MainLayout } from "@/components/layout/main-layout"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import { CampaignWizard } from "@/components/campaigns/wizard/campaign-wizard"

export default function NewCampaignPage() {
  const router = useRouter()

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => router.push("/")} title="Back to campaigns">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Create New Campaign</h1>
            <p className="text-muted-foreground">Set up a new NPS campaign in a few simple steps</p>
          </div>
        </div>

        <CampaignWizard />
      </div>
    </MainLayout>
  )
}
