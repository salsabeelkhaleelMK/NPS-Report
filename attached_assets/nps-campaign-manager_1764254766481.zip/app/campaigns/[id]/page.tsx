"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { MainLayout } from "@/components/layout/main-layout"
import { Button } from "@/components/ui/button"
import { StatusBadge } from "@/components/ui/status-badge"
import { ArrowLeft, Settings } from "lucide-react"
import { getCampaignById, updateCampaign } from "@/lib/store"
import type { Campaign } from "@/lib/types"
import { CampaignInsightsDashboard } from "@/components/campaigns/insights/campaign-insights-dashboard"
import { CampaignSettingsDrawer } from "@/components/campaigns/settings/campaign-settings-drawer"

export default function CampaignDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [campaign, setCampaign] = useState<Campaign | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [settingsOpen, setSettingsOpen] = useState(false)

  useEffect(() => {
    if (params.id) {
      const found = getCampaignById(params.id as string)
      setCampaign(found || null)
      setIsLoading(false)
    }
  }, [params.id])

  const handleUpdate = (updates: Partial<Campaign>) => {
    if (campaign) {
      const updated = updateCampaign(campaign.id, updates)
      if (updated) {
        setCampaign(updated)
      }
    }
  }

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex h-64 items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
        </div>
      </MainLayout>
    )
  }

  if (!campaign) {
    return (
      <MainLayout>
        <div className="flex h-64 flex-col items-center justify-center gap-4">
          <p className="text-muted-foreground">Campaign not found</p>
          <Button variant="outline" onClick={() => router.push("/")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Campaigns
          </Button>
        </div>
      </MainLayout>
    )
  }

  return (
    <MainLayout>
      <div className="space-y-8">
        {/* Header - Primary visual weight */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" onClick={() => router.push("/")} title="Back to campaigns">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-2xl font-semibold text-foreground">{campaign.name}</h1>
                <StatusBadge status={campaign.status} />
              </div>
              <p className="text-sm text-muted-foreground mt-0.5">{campaign.description}</p>
            </div>
          </div>
          <Button onClick={() => setSettingsOpen(true)} variant="outline" size="sm">
            <Settings className="mr-2 h-4 w-4" />
            Settings
          </Button>
        </div>

        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm">
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground">Language:</span>
            <span className="font-medium text-foreground">{campaign.language}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground">Service:</span>
            <span className="font-medium text-foreground">{campaign.serviceType}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground">Started:</span>
            <span className="font-medium text-foreground">{new Date(campaign.startDate).toLocaleDateString()}</span>
          </div>
          {campaign.endDate && (
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">Ends:</span>
              <span className="font-medium text-foreground">{new Date(campaign.endDate).toLocaleDateString()}</span>
            </div>
          )}
        </div>

        <CampaignInsightsDashboard campaign={campaign} />
      </div>

      {/* Settings Drawer */}
      <CampaignSettingsDrawer
        campaign={campaign}
        open={settingsOpen}
        onOpenChange={setSettingsOpen}
        onUpdate={handleUpdate}
      />
    </MainLayout>
  )
}
