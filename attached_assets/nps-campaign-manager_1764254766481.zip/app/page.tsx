"use client"

import { useEffect, useState } from "react"
import { MainLayout } from "@/components/layout/main-layout"
import { CampaignList } from "@/components/campaigns/campaign-list"
import { getCampaigns } from "@/lib/store"
import type { Campaign } from "@/lib/types"

export default function CampaignsPage() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    setCampaigns(getCampaigns())
    setIsLoading(false)
  }, [])

  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Campaigns</h1>
          <p className="text-muted-foreground">Manage and monitor your NPS campaigns</p>
        </div>

        {isLoading ? (
          <div className="flex h-64 items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
          </div>
        ) : (
          <CampaignList campaigns={campaigns} />
        )}
      </div>
    </MainLayout>
  )
}
