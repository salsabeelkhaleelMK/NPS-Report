# Customer Outcome Behavior - Implementation Guide

This document clarifies how the NPS Campaign Manager handles different customer segments (Detractors, Promoters, and Passives) based on their NPS scores.

## Overview

The system distinguishes between three customer types:
- **Detractors (Angry/Unhappy)**: NPS Score 0-6
- **Passives (Neutral)**: NPS Score 7-8
- **Promoters (Satisfied)**: NPS Score 9-10

---

## A. Detractors (Angry/Unhappy Customers) - Scores 0-6

### Mandatory Human Follow-up

**At least one human follow-up action MUST be enabled for detractors.**

The system provides three human follow-up options:

1. **Create dispute in Fidspark** (`outcomeRules.detractors.createFidsparkDispute`)
   - Opens a dispute case for resolution tracking
   - Automatically creates a ticket in the Fidspark system

2. **Create NPS Task in Leadspark** (`outcomeRules.detractors.createLeadsparkTask`)
   - Creates a follow-up task for the sales team
   - Integrates with Leadspark task management

3. **Create follow-up task via Webhook** (`outcomeRules.detractors.createWebhookTask`)
   - Sends data to an external system via HTTP POST
   - Configuration includes:
     - `webhookUrl`: The endpoint URL
     - `webhookSecretKey`: Authentication key
     - `webhookJsonTemplate`: Custom JSON body with variables:
       - `{{customer_id}}`
       - `{{customer_name}}`
       - `{{nps_score}}`
       - `{{feedback}}`

### AI Agent Escalation Integration

When the AI Agent is enabled (`aiAgentSettings.enabled: true`), it can automatically trigger the enabled human follow-up actions under these conditions:

- **AI Agent fails all retries** (`triggerHumanFollowUpOnFailure: true`)
  - After exhausting `maxRetries` without getting a response
  
- **Dissatisfaction detected** (`triggerHumanFollowUpOnDissatisfaction: true`)
  - AI detects negative sentiment during the call
  
- **Customer verbally complains** (`triggerHumanFollowUpOnVerbalComplaint: true`)
  - Customer explicitly expresses a complaint

When any of these triggers fire, the system automatically creates tickets/tasks using the enabled human follow-up actions.

### Configuration Location

- **Settings UI**: Campaign Settings Drawer → "Outcomes" tab
- **Data Structure**: `campaign.outcomeRules.detractors`

---

## B. Promoters (Satisfied Customers) - Scores 9-10

### Review Request Flow

Promoters are automatically routed to leave public reviews. The system:

1. **Does NOT trigger**:
   - Escalation to human follow-up
   - Dispute tickets
   - AI call retries (unless explicitly configured for promoters)

2. **DOES trigger**:
   - Review platform invitations
   - Delivery via prioritized channels

### Review Platform Configuration

**Multiple platforms can be selected** (`campaign.reviewChannels`):
- Google
- AutoScout24
- mobile.de
- Facebook
- Custom platforms (user-defined)

**Drag-to-reorder priority**: Platforms are ordered by `order` property. Higher priority platforms are displayed first to the customer.

### Delivery Channel Priority

Review requests are sent via the following channels in configurable order (`outcomeRules.promoters.deliveryChannelPriority`):

Each channel has:
- `channel`: "Email" | "SMS" | "WhatsApp"
- `enabled`: boolean
- `order`: priority number (1 = highest)

**Default priority**:
1. WhatsApp (order: 1)
2. SMS (order: 2)
3. Email (order: 3)

The system attempts delivery in order based on:
- Channel enabled status
- Customer contact availability
- Priority order

### Message Templates

Each delivery channel uses templates from `campaign.messageTemplates`:

- **Email**: `messageTemplates.email.subject` and `messageTemplates.email.body`
- **SMS**: `messageTemplates.sms.body`
- **WhatsApp**: `messageTemplates.whatsapp.templateName` and `messageTemplates.whatsapp.body`

Templates support variables like `{{name}}`, `{{dealer_name}}`, `{{review_link}}`.

### Review Performance Tracking

The system tracks promoter engagement in `campaign.insights.reviewPerformance`:

- `totalReviewRequestsSent`: Total review invitations sent
- `totalClicks`: Total clicks on review links
- `clicksByChannel`: Breakdown by Email, SMS, WhatsApp
- `clicksByPlatform`: Clicks per review platform (Google, AutoScout24, etc.)
- `engagementOverTime`: Daily engagement metrics

**Insights Display**: Campaign Detail → "Review Performance" tab

### Configuration Location

- **Settings UI**: 
  - Campaign Settings Drawer → "Reviews" tab (platforms and delivery priority)
  - Campaign Settings Drawer → "Templates" tab (message templates)
  - Campaign Settings Drawer → "Outcomes" tab (enable/disable review prompts)
- **Data Structure**: 
  - `campaign.reviewChannels`
  - `campaign.outcomeRules.promoters`
  - `campaign.messageTemplates`

---

## C. Passives (Neutral Customers) - Scores 7-8

### Default Behavior

**Passives do NOT trigger**:
- Review invitations
- Escalation to human follow-up
- AI call retries (unless explicitly configured)
- Any automated follow-up actions

### Passive-Specific Settings

Configuration in `campaign.outcomeRules.passives`:

- `noAction: true` (default): No action required, display as passive in insights only
- `customAction: string`: Optional custom action description (only active if `noAction: false`)

### Insights Display

Passives are displayed in the NPS insights:
- Counted in `insights.passivesPercent`
- Included in overall NPS score calculation
- Visible in response breakdowns

### Configuration Location

- **Settings UI**: Campaign Settings Drawer → "Outcomes" tab
- **Data Structure**: `campaign.outcomeRules.passives`

---

## Implementation Details

### Type Definitions

\`\`\`typescript
// Detractor rules
detractors: {
  createFidsparkDispute: boolean
  createLeadsparkTask: boolean
  createWebhookTask: boolean
  webhookUrl: string
  webhookSecretKey: string
  webhookJsonTemplate: string
}

// Promoter rules
promoters: {
  promptReviewChannels: boolean
  deliveryChannelPriority: DeliveryChannelPriority[]
}

// Passive rules
passives: {
  noAction: boolean
  customAction: string
}

// AI Agent Settings
aiAgentSettings: {
  enabled: boolean
  escalateToHuman: boolean
  triggerHumanFollowUpOnFailure: boolean
  triggerHumanFollowUpOnDissatisfaction: boolean
  triggerHumanFollowUpOnVerbalComplaint: boolean
  // ... other settings
}
\`\`\`

### Validation Rules

1. **Detractors**: At least one human follow-up action must be enabled
2. **Promoters**: If `promptReviewChannels` is true, at least one review channel should be configured
3. **Passives**: `customAction` is only active if `noAction` is false

### Insights Tracking

All customer outcomes are tracked in `campaign.insights`:

- **Detractor Tickets**: `insights.detractorTickets[]`
  - Includes: `source` (Fidspark/Leadspark/Webhook), `triggerReason`, `status`
  
- **Review Performance**: `insights.reviewPerformance`
  - Tracks promoter engagement across all channels and platforms
  
- **AI Agent Metrics**: `insights.aiAgentMetrics`
  - Includes escalation counts and reasons

---

## User Interface Locations

### Campaign Settings Drawer

Access via campaign detail page → Settings icon

**Tabs**:
1. **General** - Basic campaign info
2. **Audience** - Targeting configuration  
3. **Survey** - Question configuration
4. **Templates** - Email/SMS/WhatsApp message templates
5. **Follow-ups** - Multi-step follow-up sequence
6. **AI Agent** - AI calling configuration with escalation triggers
7. **Outcomes** - Detractor, Promoter, and Passive rules
8. **Reviews** - Review platforms and delivery channel priority

### Campaign Insights

Access via campaign detail page → Insight tabs

**Tabs**:
1. **NPS** - Overall NPS score and distribution
2. **AI Agent** - Call metrics and escalation data
3. **Detractors** - Ticket list and resolution tracking
4. **Review Performance** - Promoter engagement and platform performance

---

## Summary

The implementation provides comprehensive customer outcome handling:

- **Detractors** receive mandatory human attention via configurable actions
- **Promoters** are guided to leave reviews via prioritized multi-channel delivery
- **Passives** are tracked in insights without automated actions
- **AI Agent** intelligently escalates detractors to human follow-up when needed

All behaviors are fully configurable per campaign, with tracking and insights for performance monitoring.
